# MediaLab V2 — Native Java Android downloader prototype

**Independent Java Android project** (not a modified Snaptube application). This complete source ZIP is meant to be extracted by the separate GitHub Actions workflow. GPL-3.0-or-later for NewPipeExtractor compatibility.

## What is implemented

- Dark native UI with padding for Android status/navigation bars and display cutouts.
- Start screen with URL input, clipboard paste and **Download** button.
- Centered extraction loader shown for a **minimum of 5 seconds**; actual extraction can take longer.
- Second screen with native `VideoView` preview when a compatible direct preview is returned; preview can fail independently of format listing.
- Format list and bottom sheet picker. Supports one-file progressive video/audio streams and audio-only downloads in original codec.
- For a compatible **MP4 video-only track + M4A/AAC audio track**, the app downloads both streams and combines them into a single **MP4** using native `MediaExtractor` + `MediaMuxer`. No VPS or FFmpeg required for this path.
- Background download is handled by a **foreground service**, with ongoing notification, byte progress, instantaneous speed estimate, remaining bytes (if known), and completion/failure notification.
- Downloads screen with active progress, saved items and open action, stored under `Downloads/MediaLab` on Android 10+.
- Android Sharesheet `text/plain` integration. A shared URL opens a bottom sheet, then extraction opens the screen with the quality-picker sheet.
- Custom adaptive app launcher icon via Android vector resources.
- Network/extraction trace and TXT export; signed URLs, auth cookies and request query strings are omitted from logs.

## Deliberate limitations

- **Android 10+** (minSdk 29); Java 17 / compileSdk 35 / targetSdk 35.
- App ID is `pk.tearnova.medialab.v2`; it installs alongside V1 without replacing it, avoiding GitHub debug-key signature conflicts.
- The 5-second loader is a minimum animation time, not a promise that a source returns within five seconds.
- **MP3 encoding is not available**: downloaded audio retains M4A/WebM/etc. Local combining of MP4 video with AAC audio does **not** convert audio to MP3.
- Automatic merge is only attempted where the extractor supplies compatible direct HTTP MP4 video and M4A audio tracks. Incompatible codecs, encrypted/DRM media, manifests and segmented download-only formats may not work.
- Preview uses Android `VideoView` for compatible direct media URLs and is **not guaranteed** on every video/site. Some videos have only video-only preview, which is silent.
- Supports URLs recognized by NewPipeExtractor. **Instagram and TikTok are not in this version**.
- No session-cookie copying, login bypass, DRM workaround, PO-token spoofing, Snaptube proprietary backend or private APIs.
- Signed direct URLs are time-limited. Sites may respond with HTTP 403 or block automated requests; retries may require re-resolving the link.
- One concurrent download, no pause/resume/retry automation. If Android kills the app process/service or a signed link expires, the download can fail and require a new user action.
- Android 13+ requires notification permission for normal notification-drawer visibility; when denied, Android can still show foreground-service activity in its task manager.
- When a server omits Content-Length the total/remaining size is **unknown**; speed and downloaded bytes can still be shown.

## Build on GitHub (mobile only)

1. Create a new GitHub repository, for example `medialab-v2`.
2. Upload **`MediaLab_V2_Java_Source.zip`** to the **root** of that repository. **Do not extract** this ZIP on the phone.
3. Create file `.github/workflows/medialab-v2-build.yml` by pasting the short workflow provided alongside the ZIP (or uploading that short YAML to the correct folder).
4. Open `Actions` > `MediaLab V2 - Android APK` > `Run workflow` > `main` > `Run workflow`.
5. When successful, open the run summary > `Artifacts` > `MediaLab-V2-Debug-APK`. Download the ZIP, **extract it fully**, and install `app-debug.apk` from the file manager.
6. Share a supported video link into MediaLab or paste one in the app, then run the format and download test.

A green GitHub build confirms compilation only — it does not confirm on-device playback, extraction, or successful merging. Device testing remains necessary.

## Tech & third-party licenses

- [NewPipeExtractor v0.27.1](https://github.com/TeamNewPipe/NewPipeExtractor) — GPL-3.0-or-later.
- [OkHttp 4.12.0](https://github.com/square/okhttp) — Apache-2.0.
- Android platform `MediaMuxer`, `MediaExtractor`, `VideoView`, `Notification`, `MediaStore`.

This repository's app code is available under GPL-3.0-or-later; see `LICENSE`. Respect copyright and platform terms; use only media you have permission to save.
