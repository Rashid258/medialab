package pk.tearnova.medialab;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Palette {
    static final int BG = Color.rgb(9, 17, 34);
    static final int PANEL = Color.rgb(23, 35, 57);
    static final int SURFACE = Color.rgb(34, 49, 73);
    static final int WHITE = Color.rgb(242, 248, 255);
    static final int MUTED = Color.rgb(166, 184, 204);
    static final int MINT = Color.rgb(49, 220, 176);
    static final int BLACK = Color.rgb(9, 17, 34);
    static final int WARNING = Color.rgb(255, 192, 98);

    static int dp(Context c, float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }
    static GradientDrawable bg(Context c, int color, int corner) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, corner));
        return d;
    }
    static TextView text(Context c, String value, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(value);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setIncludeFontPadding(true);
        return t;
    }
    static Button button(Context c, String value, boolean accent) {
        Button b = new Button(c);
        b.setText(value);
        b.setTextAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(accent ? BLACK : WHITE);
        b.setBackground(bg(c, accent ? MINT : SURFACE, 14));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setElevation(dp(c, 1));
        return b;
    }
    static LinearLayout vertical(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    static LinearLayout horizontal(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    static LinearLayout.LayoutParams lp(Context c, int width, int height, int top) {
        LinearLayout.LayoutParams x = new LinearLayout.LayoutParams(width, height);
        x.topMargin = dp(c, top);
        return x;
    }
    static void pad(Context c, View v, int x, int y) {
        v.setPadding(dp(c,x),dp(c,y),dp(c,x),dp(c,y));
    }
    private Palette() { }
}
