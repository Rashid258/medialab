package pk.tearnova.medialab;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.schabi.newpipe.extractor.MediaFormat;
import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.DeliveryMethod;
import org.schabi.newpipe.extractor.stream.Stream;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.VideoStream;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Native Java UI — no web app, no private Snaptube components or external server. */
public final class MainActivity extends Activity {
    private static final int EXPORT_TRACE=94;
    private static final int REQUEST_NOTIFICATIONS=95;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ArrayList<Choice> choices=new ArrayList<>();
    private final StringBuilder logs=new StringBuilder();
    private FrameLayout frame;
    private LinearLayout shell,body,bottomBar;
    private View loader;
    private TextView loaderText;
    private EditText urlInput;
    private VideoView previewPlayer;
    private String typedUrl="";
    private String videoTitle="Media";
    private String uploader="";
    private String currentPage="home";
    private String savedPreviewUrl="";
    private boolean inspecting=false;
    private boolean resumed=false;
    private int lastInsetLeft,lastInsetTop,lastInsetRight,lastInsetBottom;
    private final Runnable refreshDownloads=new Runnable(){
        @Override public void run(){
            if(resumed && "downloads".equals(currentPage)) updateDownloadsPanel();
            ui.postDelayed(this,1100);
        }
    };
    private LinearLayout downloadsPanel;

    private static final class Choice {
        String name, subtitle, ext;
        Stream main, audio;
        boolean available;
        Choice(String name,String sub,String suffix,Stream m,Stream a,boolean yes){
            this.name=name;subtitle=sub;ext=suffix;main=m;audio=a;available=yes;
        }
    }

    @Override public void onCreate(Bundle savedState){
        super.onCreate(savedState);
        getWindow().setStatusBarColor(Palette.BG);
        getWindow().setNavigationBarColor(Palette.BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        NewPipe.init(new HttpExtractorDownloader(this::trace));
        setupShell();
        showHome();
        ui.postDelayed(refreshDownloads,1100);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQUEST_NOTIFICATIONS);
        handleIntent(getIntent());
        trace("MediaLab V2 • on-device NewPipeExtractor initialized");
    }
    @Override protected void onResume(){super.onResume();resumed=true;}
    @Override protected void onPause(){resumed=false;super.onPause();}
    @Override public void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);handleIntent(i);}

    private void handleIntent(Intent intent){
        if(intent==null) return;
        if(intent.getBooleanExtra("open_downloads",false)){
            showDownloads();return;
        }
        if(Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())){
            String incoming=extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT));
            if(incoming!=null){
                typedUrl=incoming;
                if(urlInput!=null)urlInput.setText(incoming);
                ui.post(()->showSharedLinkSheet(incoming));
            } else toast("Shared text does not contain a valid link");
        }
    }
    private String extractUrl(String text){
        if(text==null) return null;
        Matcher m=Pattern.compile("https?://[^\\s<>]+",Pattern.CASE_INSENSITIVE).matcher(text);
        if(!m.find())return null;
        return m.group().replaceAll("[.,;!]+$","");
    }

    private void setupShell(){
        frame=new FrameLayout(this);
        frame.setBackgroundColor(Palette.BG);
        shell=Palette.vertical(this);
        frame.addView(shell,new FrameLayout.LayoutParams(-1,-1));
        setContentView(frame);
        if(Build.VERSION.SDK_INT>=30){
            frame.setOnApplyWindowInsetsListener((v,insets)->{
                android.graphics.Insets safe=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                applyInsets(safe.left,safe.top,safe.right,safe.bottom);
                return insets;
            });
        } else {
            frame.setOnApplyWindowInsetsListener((v,insets)->{
                applyInsets(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
                return insets;
            });
        }
        buildScaffold();
    }
    private void applyInsets(int l,int t,int r,int b){
        if(l!=lastInsetLeft||t!=lastInsetTop||r!=lastInsetRight||b!=lastInsetBottom){
            lastInsetLeft=l;lastInsetTop=t;lastInsetRight=r;lastInsetBottom=b;
            frame.setPadding(l,t,r,b);
        }
    }
    private void buildScaffold(){
        LinearLayout top=Palette.horizontal(this);
        top.setPadding(dp(18),dp(15),dp(18),dp(12));
        TextView brand=Palette.text(this,"◆  MediaLab",23,Palette.WHITE,true);
        top.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView version=Palette.text(this,"STUDIO  /  V2",11,Palette.MINT,true);
        top.addView(version);
        shell.addView(top);
        View line=new View(this);line.setBackgroundColor(Palette.SURFACE);
        shell.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        FrameLayout holder=new FrameLayout(this);
        shell.addView(holder,new LinearLayout.LayoutParams(-1,0,1));
        body=Palette.vertical(this);
        holder.addView(body,new FrameLayout.LayoutParams(-1,-1));
        bottomBar=Palette.horizontal(this);
        bottomBar.setPadding(dp(8),dp(7),dp(8),dp(9));
        bottomBar.setBackgroundColor(Palette.PANEL);
        shell.addView(bottomBar,new LinearLayout.LayoutParams(-1,dp(67)));
        renderNavigation();
    }
    private void renderNavigation(){
        bottomBar.removeAllViews();
        tab("⌂  Home","home",()->showHome());
        tab("↓  Downloads","downloads",()->showDownloads());
        tab("≡  Trace","trace",()->showTrace());
    }
    private void tab(String title,String id,Runnable action){
        boolean active=currentPage.equals(id)|| (currentPage.equals("details")&&id.equals("home"));
        TextView b=Palette.text(this,title,13,active?Palette.MINT:Palette.MUTED,true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Palette.bg(this,active?Palette.SURFACE:Palette.PANEL,10));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);
        p.leftMargin=dp(3);p.rightMargin=dp(3);
        bottomBar.addView(b,p);
        b.setOnClickListener(v->action.run());
    }
    private ScrollView scrollPage(){
        body.removeAllViews();
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        LinearLayout col=Palette.vertical(this);
        col.setPadding(dp(18),dp(21),dp(18),dp(28));
        scroll.addView(col);
        body.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        lastColumn=col;
        return scroll;
    }
    private LinearLayout lastColumn;
    private void heading(String tag,String title,String sub){
        TextView overline=Palette.text(this,tag,11,Palette.MINT,true);
        lastColumn.addView(overline);
        TextView h=Palette.text(this,title,29,Palette.WHITE,true);
        lastColumn.addView(h,Palette.lp(this,-1,-2,10));
        TextView d=Palette.text(this,sub,13,Palette.MUTED,false);
        lastColumn.addView(d,Palette.lp(this,-1,-2,7));
    }
    private void showHome(){
        pausePreview();
        currentPage="home";
        renderNavigation();
        scrollPage();
        heading("SAVE WHAT MATTERS","Your media.\nYour device.",
            "Paste a supported link and inspect available playback qualities. No VPS required.");
        LinearLayout card=Palette.vertical(this);
        card.setPadding(dp(16),dp(18),dp(16),dp(17));
        card.setBackground(Palette.bg(this,Palette.PANEL,20));
        lastColumn.addView(card,Palette.lp(this,-1,-2,24));
        card.addView(Palette.text(this,"VIDEO LINK",12,Palette.MINT,true));
        urlInput=new EditText(this);
        urlInput.setTextColor(Palette.WHITE);
        urlInput.setHintTextColor(Palette.MUTED);
        urlInput.setTextSize(14);
        urlInput.setSingleLine(false);
        urlInput.setMinLines(2);urlInput.setMaxLines(4);
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setHint("https://youtube.com/shorts/...");
        urlInput.setText(typedUrl);
        urlInput.setBackground(Palette.bg(this,Palette.SURFACE,12));
        urlInput.setPadding(dp(14),dp(14),dp(14),dp(14));
        card.addView(urlInput,Palette.lp(this,-1,-2,12));
        Button paste=Palette.button(this,"Paste from clipboard",false);
        card.addView(paste,Palette.lp(this,-1,dp(42),11));
        paste.setOnClickListener(v->{
            ClipboardManager c=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            if(c.hasPrimaryClip()){
                ClipData clip=c.getPrimaryClip();
                if(clip!=null&&clip.getItemCount()>0){
                    String value=clip.getItemAt(0).coerceToText(this).toString();
                    urlInput.setText(value);
                    urlInput.setSelection(urlInput.length());
                }
            }
        });
        Button action=Palette.button(this,"↓   Download",true);
        lastColumn.addView(action,Palette.lp(this,-1,dp(54),17));
        action.setOnClickListener(v->{
            String candidate=extractUrl(urlInput.getText().toString().trim());
            if(candidate==null){toast("Paste a valid http(s) video URL");return;}
            typedUrl=candidate;
            inspect(candidate,false);
        });
        LinearLayout help=Palette.vertical(this);
        help.setPadding(dp(16),dp(18),dp(16),dp(18));
        help.setBackground(Palette.bg(this,Palette.PANEL,18));
        help.addView(Palette.text(this,"HOW IT WORKS",12,Palette.MINT,true));
        help.addView(Palette.text(this,"01   Paste or share a video link\n\n02   Preview and choose quality\n\n03   Download in background",14,Palette.WHITE,false),Palette.lp(this,-1,-2,12));
        lastColumn.addView(help,Palette.lp(this,-1,-2,24));
        lastColumn.addView(Palette.text(this,
            "Only media you have permission to save. Restricted, private and DRM content is not unlocked.",12,Palette.MUTED,false),Palette.lp(this,-1,-2,18));
    }

    private void inspect(String url,boolean autoSheet){
        if(inspecting) {toast("Already inspecting a link");return;}
        inspecting=true;
        typedUrl=url;
        showLoader("Resolving media…\nPreparing preview and qualities");
        long started=SystemClock.elapsedRealtime();
        trace("Resolve > "+new Uri.Builder().scheme(Uri.parse(url).getScheme()).authority(Uri.parse(url).getHost()).build());
        worker.execute(()->{
            StreamInfo info=null; Exception error=null;
            try{info=StreamInfo.getInfo(url);}catch(Exception ex){error=ex;}
            final StreamInfo outcome=info;
            final Exception failure=error;
            long delay=Math.max(0,5000-(SystemClock.elapsedRealtime()-started));
            ui.postDelayed(()->{
                hideLoader();inspecting=false;
                if(outcome!=null){
                    buildChoices(outcome);
                    videoTitle=outcome.getName()==null?"Untitled video":outcome.getName();
                    uploader=outcome.getUploaderName()==null?"":outcome.getUploaderName();
                    showDetails();
                    if(autoSheet) ui.postDelayed(this::showQualitySheet,350);
                    trace("Resolved: "+choices.size()+" entries");
                } else {
                    String message=failure==null?"Unknown extractor problem":safeError(failure.getMessage());
                    trace("Resolve failed: "+(failure==null?"unknown":failure.getClass().getSimpleName())+" "+message);
                    showErrorSheet(message);
                }
            },delay);
        });
    }

    private void buildChoices(StreamInfo info){
        choices.clear();
        List<AudioStream> audios=info.getAudioStreams();
        AudioStream bestAac=null;
        for(AudioStream a:audios){
            String extension=ext(a,"m4a");
            if("m4a".equals(extension)&&usable(a)&& (bestAac==null||a.getAverageBitrate()>bestAac.getAverageBitrate())) bestAac=a;
        }
        List<VideoStream> videos=new ArrayList<>(info.getVideoStreams());
        videos.sort((a,b)->Integer.compare(height(b),height(a)));
        for(VideoStream v:videos){
            String extension=ext(v,"mp4");
            boolean supported=usable(v);
            choices.add(new Choice(v.getResolution()+" • "+extension.toUpperCase(Locale.ROOT),
                "Video + audio  •  One file",extension,v,null,supported));
        }
        List<VideoStream> only=new ArrayList<>(info.getVideoOnlyStreams());
        only.sort((a,b)->Integer.compare(height(b),height(a)));
        for(VideoStream v:only){
            String extension=ext(v,"mp4");
            AudioStream paired="mp4".equals(extension)?bestAac:null;
            boolean playable=usable(v)&&paired!=null;
            choices.add(new Choice(v.getResolution()+" • "+extension.toUpperCase(Locale.ROOT),
                paired!=null?"Video + AAC audio  •  Auto-merge on phone":"Video only • No compatible audio",extension,v,paired,playable));
        }
        for(AudioStream a:audios){
            String extension=ext(a,"m4a");
            choices.add(new Choice("Audio • "+Math.max(0,a.getAverageBitrate())+" kbps",
                "Original "+extension.toUpperCase(Locale.ROOT)+" audio • Not converted to MP3",
                extension,a,null,usable(a)));
        }
        savedPreviewUrl="";
        for(Choice c:choices){
            if(c.main instanceof VideoStream&&c.main.isUrl()&&c.main.getContent().startsWith("https://") && c.audio==null){
                savedPreviewUrl=c.main.getContent();break;
            }
        }
        if(savedPreviewUrl.isEmpty()) {
            for(Choice c:choices){if(c.main instanceof VideoStream&&usable(c.main)) {savedPreviewUrl=c.main.getContent();break;}}
        }
    }
    private int height(VideoStream v){
        try {String t=v.getResolution();Matcher m=Pattern.compile("(\\d+)").matcher(t);return m.find()?Integer.parseInt(m.group(1)):0;}
        catch(Exception e){return 0;}
    }
    private String ext(Stream stream,String fallback){
        MediaFormat format=stream.getFormat();
        String suffix=format==null?null:format.getSuffix();
        return suffix==null?fallback:suffix.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");
    }
    private boolean usable(Stream s){
        return s!=null&&s.isUrl()&&s.getContent().startsWith("https://")&&s.getDeliveryMethod()==DeliveryMethod.PROGRESSIVE_HTTP;
    }

    private void showDetails(){
        currentPage="details";renderNavigation();scrollPage();
        heading("LINK RESOLVED","Ready to preview",uploader);
        LinearLayout playerCard=Palette.vertical(this);
        playerCard.setPadding(dp(12),dp(12),dp(12),dp(12));
        playerCard.setBackground(Palette.bg(this,Palette.PANEL,20));
        lastColumn.addView(playerCard,Palette.lp(this,-1,-2,20));
        FrameLayout playerHolder=new FrameLayout(this);
        playerHolder.setBackground(Palette.bg(this,Palette.BLACK,15));
        playerCard.addView(playerHolder,new LinearLayout.LayoutParams(-1,dp(230)));
        if(!savedPreviewUrl.isEmpty()){
            previewPlayer=new VideoView(this);
            playerHolder.addView(previewPlayer,new FrameLayout.LayoutParams(-1,-1));
            MediaController controller=new MediaController(this);
            controller.setAnchorView(previewPlayer);
            previewPlayer.setMediaController(controller);
            previewPlayer.setOnErrorListener((mp,what,extra)->{
                toast("Preview unavailable; formats may still download");return true;
            });
            Button play=Palette.button(this,"▶   Play preview",true);
            FrameLayout.LayoutParams playParams=new FrameLayout.LayoutParams(dp(184),dp(51),Gravity.CENTER);
            playerHolder.addView(play,playParams);
            play.setOnClickListener(v->{
                play.setVisibility(View.GONE);
                try{previewPlayer.setVideoURI(Uri.parse(savedPreviewUrl));previewPlayer.start();}
                catch(Exception ex){toast("Preview unavailable");play.setVisibility(View.VISIBLE);}
            });
        }else{
            TextView empty=Palette.text(this,"▶\n\nPreview is not available for this stream",16,Palette.MUTED,true);
            empty.setGravity(Gravity.CENTER);
            playerHolder.addView(empty,new FrameLayout.LayoutParams(-1,-1));
        }
        TextView name=Palette.text(this,videoTitle,17,Palette.WHITE,true);
        playerCard.addView(name,Palette.lp(this,-1,-2,16));
        playerCard.addView(Palette.text(this,"Select a stream below. Compatible MP4 + M4A tracks merge into one file locally.",12,Palette.MUTED,false),Palette.lp(this,-1,-2,7));
        Button choose=Palette.button(this,"Choose quality   ↓",true);
        lastColumn.addView(choose,Palette.lp(this,-1,dp(50),16));
        choose.setOnClickListener(v->showQualitySheet());
        TextView title=Palette.text(this,"AVAILABLE FORMATS",12,Palette.MINT,true);
        lastColumn.addView(title,Palette.lp(this,-1,-2,25));
        if(choices.isEmpty())lastColumn.addView(Palette.text(this,"No playable formats returned by the extractor.",14,Palette.MUTED,false));
        for(Choice c:choices)lastColumn.addView(formatCard(c,false),Palette.lp(this,-1,-2,9));
        lastColumn.addView(Palette.text(this,"Some sites may require sign-in or reject automated requests. MP3 transcoding is not included.",12,Palette.MUTED,false),Palette.lp(this,-1,-2,20));
    }
    private View formatCard(Choice c,boolean inSheet){
        LinearLayout row=Palette.horizontal(this);
        row.setPadding(dp(13),dp(13),dp(12),dp(13));
        row.setBackground(Palette.bg(this,Palette.PANEL,14));
        LinearLayout info=Palette.vertical(this);
        info.addView(Palette.text(this,c.name,15,Palette.WHITE,true));
        info.addView(Palette.text(this,c.subtitle,12,c.available?Palette.MUTED:Palette.WARNING,false),Palette.lp(this,-1,-2,5));
        row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        Button button=Palette.button(this,c.available?"Save":"Info",c.available);
        row.addView(button,new LinearLayout.LayoutParams(dp(77),dp(42)));
        button.setOnClickListener(v->{
            if(!c.available){toast("This format cannot be downloaded or merged by V2");return;}
            startDownload(c);
            if(inSheet&&activeSheet!=null){activeSheet.dismiss();activeSheet=null;}
        });
        return row;
    }

    private Dialog activeSheet;
    private Dialog sheet(LinearLayout content){
        Dialog dialog=new Dialog(this);
        dialog.getWindow();
        content.setPadding(dp(18),dp(19),dp(18),dp(30));
        content.setBackground(Palette.bg(this,Palette.PANEL,24));
        dialog.setContentView(content);
        Window w=dialog.getWindow();
        if(w!=null){
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams p=w.getAttributes();
            p.width=WindowManager.LayoutParams.MATCH_PARENT;
            p.height=WindowManager.LayoutParams.WRAP_CONTENT;
            p.gravity=Gravity.BOTTOM;
            p.dimAmount=0.55f;
            p.windowAnimations=android.R.style.Animation_Dialog;
            w.setAttributes(p);
        }
        return dialog;
    }
    private void showSharedLinkSheet(String shared){
        if(isFinishing()||isDestroyed())return;
        if(activeSheet!=null)activeSheet.dismiss();
        LinearLayout content=Palette.vertical(this);
        content.addView(Palette.text(this,"SHARED TO MEDIALAB",12,Palette.MINT,true));
        content.addView(Palette.text(this,"Ready to inspect?",24,Palette.WHITE,true),Palette.lp(this,-1,-2,10));
        String display=shared.length()>90?shared.substring(0,90)+"…":shared;
        content.addView(Palette.text(this,display,13,Palette.MUTED,false),Palette.lp(this,-1,-2,12));
        Button action=Palette.button(this,"↓   Continue to download",true);
        content.addView(action,Palette.lp(this,-1,dp(51),22));
        Dialog d=sheet(content);activeSheet=d;
        action.setOnClickListener(v->{d.dismiss();activeSheet=null;showHome();inspect(shared,true);});
        d.show();styleSheetWindow(d);
    }
    private void showQualitySheet(){
        if(isFinishing())return;
        if(activeSheet!=null)activeSheet.dismiss();
        LinearLayout content=Palette.vertical(this);
        content.addView(Palette.text(this,"SELECT QUALITY",12,Palette.MINT,true));
        content.addView(Palette.text(this,"Download to your device",23,Palette.WHITE,true),Palette.lp(this,-1,-2,9));
        content.addView(Palette.text(this,"Compatible audio and video are combined automatically.",12,Palette.MUTED,false),Palette.lp(this,-1,-2,7));
        ScrollView scroll=new ScrollView(this);
        LinearLayout rows=Palette.vertical(this);
        for(Choice c:choices)rows.addView(formatCard(c,true),Palette.lp(this,-1,-2,9));
        if(choices.isEmpty())rows.addView(Palette.text(this,"No downloadable format available.",13,Palette.WARNING,false));
        scroll.addView(rows);
        content.addView(scroll,Palette.lp(this,-1,dp(400),14));
        Dialog dialog=sheet(content);activeSheet=dialog;
        dialog.show();styleSheetWindow(dialog);
    }
    private void showErrorSheet(String message){
        LinearLayout content=Palette.vertical(this);
        content.addView(Palette.text(this,"LINK INSPECTION FAILED",12,Palette.WARNING,true));
        content.addView(Palette.text(this,"Could not load formats",22,Palette.WHITE,true),Palette.lp(this,-1,-2,10));
        content.addView(Palette.text(this,message,13,Palette.MUTED,false),Palette.lp(this,-1,-2,12));
        Button close=Palette.button(this,"Back to home",true);
        content.addView(close,Palette.lp(this,-1,dp(50),17));
        Dialog d=sheet(content);activeSheet=d;
        close.setOnClickListener(v->{d.dismiss();activeSheet=null;showHome();});
        d.show();styleSheetWindow(d);
    }
    private void styleSheetWindow(Dialog d){
        Window w=d.getWindow();if(w==null)return;
        w.setLayout(-1,-2);w.setGravity(Gravity.BOTTOM);
        w.setNavigationBarColor(Palette.PANEL);
    }

    private void startDownload(Choice selected){
        if(!usable(selected.main))return;
        if(DownloadService.isActive()) {
            toast("One download is already running. Check Downloads tab.");
            showDownloads();return;
        }

        Intent service=new Intent(this,DownloadService.class);
        service.putExtra(DownloadService.EXTRA_URL,selected.main.getContent());
        service.putExtra(DownloadService.EXTRA_TITLE,videoTitle);
        service.putExtra(DownloadService.EXTRA_EXT,selected.ext);
        if(selected.audio!=null)service.putExtra(DownloadService.EXTRA_AUDIO,selected.audio.getContent());
        try{
            if(Build.VERSION.SDK_INT>=26)startForegroundService(service);
            else startService(service);
            trace("Download queued: "+selected.name+" (signed URL omitted)");
            showDownloads();
        }catch(Exception ex){toast("Unable to start foreground download: "+safeError(ex.getMessage()));}
    }

    private void showDownloads(){
        pausePreview();currentPage="downloads";renderNavigation();scrollPage();
        heading("BACKGROUND DOWNLOADS","Your downloads","Watch live speed and saved media even after switching apps.");
        downloadsPanel=Palette.vertical(this);
        lastColumn.addView(downloadsPanel,Palette.lp(this,-1,-2,20));
        updateDownloadsPanel();
    }
    private void updateDownloadsPanel(){
        if(downloadsPanel==null||!"downloads".equals(currentPage))return;
        downloadsPanel.removeAllViews();
        android.content.SharedPreferences prefs=getSharedPreferences(DownloadService.PREFS,MODE_PRIVATE);
        String raw=prefs.getString("current","");
        try{
            JSONObject c=raw.isEmpty()?null:new JSONObject(raw);
            if(c!=null){
                LinearLayout card=Palette.vertical(this);
                card.setBackground(Palette.bg(this,Palette.PANEL,18));
                card.setPadding(dp(16),dp(18),dp(16),dp(18));
                downloadsPanel.addView(card);
                String status=c.optString("status","idle");
                card.addView(Palette.text(this,status.equals("completed")?"✓  COMPLETED":status.equals("failed")?"!  FAILED":"↓  IN PROGRESS",12,
                    status.equals("failed")?Palette.WARNING:Palette.MINT,true));
                card.addView(Palette.text(this,c.optString("title","Media"),17,Palette.WHITE,true),Palette.lp(this,-1,-2,11));
                card.addView(Palette.text(this,c.optString("phase","Preparing"),13,Palette.MUTED,false),Palette.lp(this,-1,-2,7));
                long done=c.optLong("done",0),total=c.optLong("total",-1);
                int progress=total>0?(int)Math.min(100,(done*100)/total):0;
                ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
                bar.setIndeterminate(total<=0&&!status.equals("completed")&&!status.equals("failed"));
                bar.setMax(100);bar.setProgress(progress);
                bar.setProgressTintList(ColorStateList.valueOf(Palette.MINT));
                card.addView(bar,Palette.lp(this,-1,dp(9),15));
                LinearLayout stats=Palette.horizontal(this);
                stats.setGravity(Gravity.CENTER_VERTICAL);
                stats.setPadding(0,dp(15),0,0);
                String amount=DownloadService.human(done)+" / "+DownloadService.human(total);
                String remaining=total>0?DownloadService.human(Math.max(0,total-done)):"unknown";
                stats.addView(stat("Downloaded",amount),new LinearLayout.LayoutParams(0,-2,1));
                stats.addView(stat("Remaining",remaining),new LinearLayout.LayoutParams(0,-2,1));
                card.addView(stats);
                card.addView(Palette.text(this,"Speed: "+DownloadService.human((long)c.optDouble("speed",0))+"/s",14,Palette.MINT,true),Palette.lp(this,-1,-2,13));
                if(status.equals("completed"))card.addView(Palette.text(this,"Saved in Downloads / MediaLab",12,Palette.MUTED,false),Palette.lp(this,-1,-2,10));
            }
            JSONArray history=new JSONArray(prefs.getString("history","[]"));
            downloadsPanel.addView(Palette.text(this,"RECENT FILES",12,Palette.MINT,true),Palette.lp(this,-1,-2,25));
            if(history.length()==0)downloadsPanel.addView(Palette.text(this,"Your completed downloads will appear here.",14,Palette.MUTED,false),Palette.lp(this,-1,-2,12));
            for(int i=0;i<history.length();i++){
                JSONObject item=history.optJSONObject(i);if(item==null)continue;
                LinearLayout row=Palette.horizontal(this);
                row.setPadding(dp(12),dp(12),dp(12),dp(12));
                row.setBackground(Palette.bg(this,Palette.PANEL,12));
                TextView entry=Palette.text(this,"✓  "+item.optString("title","Download")+"\n"+item.optString("ext","file").toUpperCase(Locale.ROOT),13,Palette.WHITE,false);
                row.addView(entry,new LinearLayout.LayoutParams(0,-2,1));
                Button open=Palette.button(this,"Open",false);
                row.addView(open,new LinearLayout.LayoutParams(dp(78),dp(40)));
                String media=item.optString("uri","");String ex=item.optString("ext","mp4");
                open.setOnClickListener(v->openDownloaded(media,ex));
                downloadsPanel.addView(row,Palette.lp(this,-1,-2,9));
            }
        }catch(Exception ex){
            downloadsPanel.addView(Palette.text(this,"Download status unavailable. Check notification.",13,Palette.WARNING,false));
        }
    }
    private LinearLayout stat(String heading,String value){
        LinearLayout stack=Palette.vertical(this);
        stack.addView(Palette.text(this,heading,11,Palette.MUTED,false));
        stack.addView(Palette.text(this,value,14,Palette.WHITE,true),Palette.lp(this,-1,-2,5));
        return stack;
    }
    private void openDownloaded(String uri,String suffix){
        if(uri.isEmpty())return;
        try{
            Intent open=new Intent(Intent.ACTION_VIEW);
            open.setDataAndType(Uri.parse(uri),suffix.equals("mp4")?"video/mp4":suffix.equals("m4a")?"audio/mp4":"*/*");
            open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(open,"Open downloaded media"));
        }catch(Exception ex){toast("Cannot open this file from the app");}
    }

    private void showTrace(){
        pausePreview();currentPage="trace";renderNavigation();scrollPage();
        heading("EXTRACTION DIAGNOSTICS","Trace & debug","HTTP host/path and status only. Tokens and signed URLs are deliberately omitted.");
        TextView lines=Palette.text(this,logs.toString(),11,Palette.WHITE,false);
        lines.setTypeface(Typeface.MONOSPACE);
        lines.setPadding(dp(13),dp(13),dp(13),dp(13));
        lines.setBackground(Palette.bg(this,Palette.PANEL,15));
        lastColumn.addView(lines,Palette.lp(this,-1,-2,19));
        Button export=Palette.button(this,"Export trace as TXT",true);
        lastColumn.addView(export,Palette.lp(this,-1,dp(50),16));
        export.setOnClickListener(v->{
            Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/plain");intent.putExtra(Intent.EXTRA_TITLE,"medialab-v2-trace.txt");
            startActivityForResult(intent,EXPORT_TRACE);
        });
    }
    private void trace(String s){
        ui.post(()->{
            if(logs.length()>30000)logs.delete(0,12000);
            logs.append(System.currentTimeMillis()).append("  ").append(s).append('\n');
        });
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==EXPORT_TRACE&&result==RESULT_OK&&data!=null&&data.getData()!=null){
            try(OutputStream stream=getContentResolver().openOutputStream(data.getData())){
                if(stream==null)throw new IllegalStateException("No document stream");
                stream.write(logs.toString().getBytes(StandardCharsets.UTF_8));
                toast("Trace exported");
            }catch(Exception e){toast("Export failed");}
        }
    }

    private void showLoader(String message){
        if(loader!=null)frame.removeView(loader);
        FrameLayout backdrop=new FrameLayout(this);
        backdrop.setBackgroundColor(0xE8091122);
        LinearLayout center=Palette.vertical(this);
        center.setGravity(Gravity.CENTER);
        center.setPadding(dp(22),dp(24),dp(22),dp(24));
        center.setBackground(Palette.bg(this,Palette.PANEL,23));
        ProgressBar ring=new ProgressBar(this);
        ring.setIndeterminateTintList(ColorStateList.valueOf(Palette.MINT));
        center.addView(ring,new LinearLayout.LayoutParams(dp(52),dp(52)));
        loaderText=Palette.text(this,message,16,Palette.WHITE,true);
        loaderText.setGravity(Gravity.CENTER);
        center.addView(loaderText,Palette.lp(this,-1,-2,19));
        center.addView(Palette.text(this,"A little studio magic…",12,Palette.MUTED,false),Palette.lp(this,-1,-2,9));
        FrameLayout.LayoutParams layout=new FrameLayout.LayoutParams(dp(300),-2,Gravity.CENTER);
        backdrop.addView(center,layout);
        frame.addView(backdrop,new FrameLayout.LayoutParams(-1,-1));
        loader=backdrop;
    }
    private void hideLoader(){if(loader!=null){frame.removeView(loader);loader=null;}}
    private void pausePreview(){
        if(previewPlayer!=null){try{previewPlayer.stopPlayback();}catch(Exception ignored){}previewPlayer=null;}
    }
    private String safeError(String message){
        if(message==null)return "Unknown error";
        String text=message.replaceAll("https?://[^\\s\"'<>]+","[URL hidden]")
            .replaceAll("(?i)(cookie|authorization|token|signature)[=:]\\S+","[secret hidden]");
        return text.length()>180?text.substring(0,180):text;
    }
    private int dp(int n){return Palette.dp(this,n);}
    private void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){
        if("details".equals(currentPage)||"downloads".equals(currentPage)||"trace".equals(currentPage))showHome();
        else super.onBackPressed();
    }
    @Override protected void onDestroy(){
        resumed=false;ui.removeCallbacks(refreshDownloads);
        pausePreview();worker.shutdownNow();super.onDestroy();
    }
}
