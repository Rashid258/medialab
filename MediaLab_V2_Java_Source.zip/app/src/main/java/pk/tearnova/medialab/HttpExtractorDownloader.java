package pk.tearnova.medialab;

import android.net.Uri;

import org.schabi.newpipe.extractor.downloader.Downloader;
import org.schabi.newpipe.extractor.downloader.Request;
import org.schabi.newpipe.extractor.downloader.Response;
import org.schabi.newpipe.extractor.exceptions.ReCaptchaException;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;


import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;

public final class HttpExtractorDownloader extends Downloader {
    public interface Reporter { void log(String line); }

    private final Reporter reporter;
    private final OkHttpClient client = new OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .followRedirects(true)
            .build();

    public HttpExtractorDownloader(Reporter reporter) {
        this.reporter = reporter;
    }

    @Override
    public Response execute(Request request) throws IOException, ReCaptchaException {
        String method = request.httpMethod().toUpperCase(java.util.Locale.ROOT);
        String safePath = safePath(request.url());
        long start = System.currentTimeMillis();
        reporter.log("HTTP > " + method + " " + safePath);
        okhttp3.Request.Builder builder = new okhttp3.Request.Builder().url(request.url());
        Map<String, List<String>> headers = request.headers();
        if (headers != null) {
            for (Map.Entry<String, List<String>> e : headers.entrySet()) {
                for (String v : e.getValue()) {
                    builder.addHeader(e.getKey(), v);
                }
            }
        }
        if ("POST".equals(method) || "PUT".equals(method) || "PATCH".equals(method)) {
            String contentType = "application/octet-stream";
            if (headers != null) {
                for (Map.Entry<String, List<String>> h : headers.entrySet()) {
                    if ("content-type".equalsIgnoreCase(h.getKey()) && !h.getValue().isEmpty()) {
                        contentType = h.getValue().get(0);
                    }
                }
            }
            byte[] data = request.dataToSend();
            if (data == null) data = new byte[0];
            builder.method(method, RequestBody.create(data, MediaType.parse(contentType)));
        } else if ("HEAD".equals(method)) {
            builder.head();
        } else if ("GET".equals(method)) {
            builder.get();
        } else {
            throw new IOException("Unsupported extractor HTTP method: " + method);
        }
        try (okhttp3.Response res = client.newCall(builder.build()).execute()) {
            String body = res.body() == null ? "" : res.body().string();
            reporter.log("HTTP < " + res.code() + " " + safePath + " (" +
                    (System.currentTimeMillis() - start) + "ms, " + body.length() + " chars)");
            // The log deliberately excludes query strings, cookies, request bodies, and signed URLs.
            return new Response(res.code(), res.message(), res.headers().toMultimap(),
                    body, res.request().url().toString());
        } catch (IOException ex) {
            reporter.log("HTTP ! " + safePath + " -> " + ex.getClass().getSimpleName());
            throw ex;
        }
    }

    private String safePath(String raw) {
        try {
            Uri uri = Uri.parse(raw);
            return uri.getScheme() + "://" + uri.getHost() + uri.getPath();
        } catch (Exception e) {
            return "[invalid-url]";
        }
    }
}
