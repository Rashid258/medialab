# MediaLab V3 — Android Java, on-device media downloader

A clean Java-based Android prototype, not a patched Snaptube build. Uses **NewPipeExtractor v0.27.1**, **Media3 ExoPlayer 1.11.1**, Android foreground downloads and MediaMuxer. No VPS or Firebase.

## V3 functionality

- Android status/navigation-bar safe areas. Two centered, enlarged **icon-only** bottom navigation buttons (Home, Downloads).
- Clean Home: URL field and **Download** button only; no extra home cards or Download icon.
- Download tap resolves link and shows a centered loader for **at least 5 seconds** (potentially longer when network extraction is slow).
- Video preview page uses **Media3 ExoPlayer** with play/pause/seek and a separate **Volume on / Unmute** control. Audio enabled by default.
- Qualities display only format and quality labels; no "Video + AAC" subtitles. YouTube video-only MP4 formats appear **only if compatible AAC/M4A audio exists for an automatic MP4 merger**. Video-only entries without a merge partner are excluded. Muxed video/audio qualities are shown as normal.
- YouTube audio-only M4A/WebM streams remain available as audio choices; this prototype **does not convert to MP3**.
- For compatible YouTube MP4+AAC, video and audio are downloaded and merged locally via Android MediaExtractor + MediaMuxer into one file. ExoPlayer previews separate audio+video as one stream when supported.
- Public Instagram Reel and video-post URLs (`/reel/`, `/p/`, `/tv/`) are recognized by a **best-effort page-metadata resolver**. If Instagram exposes public video metadata, MediaLab can preview/save the MP4. **Not every public Reel exposes a usable media URL; Instagram may require authentication or block metadata.** No private APIs, account login bypass, sessions or cookies are harvested. Instagram support is experimental and must be tested on a real link/device.
- Android Sharesheet `SEND text/plain`: shows a shared-link bottom modal; when selected, automatically shows qualities in a bottom sheet.
- Downloads page: progress %, bytes, estimated total/remaining MB, speed, and a **Ready to play** button once 8% is known to be downloaded. This button opens ExoPlayer streaming from the source URL **while the download continues**; it is **not partial-file/offline playback**.
- Completion notification + foreground progress notification and in-app recent Downloads with Play buttons.
- Adaptive launcher icon included. `pk.tearnova.medialab.v3` allows installation alongside V2 without debug-key clashes.

## Limitations and permissions

- Android 10+ (minSdk 29); compile SDK 36 / target SDK 35, Java 17. No private/premium/DRM unlock, and no guarantee that signed media URLs remain playable.
- Background downloads use Android foreground `dataSync` service, not the system DownloadManager. One download at a time. No automatic resume on kill/restart.
- `Ready to play` appears at >=8% only when total length is known and the service is still running. It **streams online**, rather than reading partially downloaded files.
- MediaMuxer handles supported MP4 video and AAC audio; incompatible codecs are not silently converted. No MP3 encoder. Browser auth and site restrictions remain enforced.
- Only download media you own or have permission to save; follow source platform terms and respect creator copyrights.

## GitHub build from phone

1. Upload **`MediaLab_V3_Java_Source.zip`** to the repo root. Leave it zipped.
2. In the same repo create `.github/workflows/medialab-v3-build.yml` using the provided separate small YAML file.
3. Open Actions → **MediaLab V3 - Java APK** → Run workflow → main → Run workflow.
4. After successful build download artifact `MediaLab-V3-Debug-APK` and **extract** its ZIP. Install `app-debug.apk` using Android Files, not directly inside RAR.
5. Test a public YouTube Short and a public Instagram Reel. Review sound/mute, adaptive MP4 merge, progress, saved Play action and notifications. A green CI result confirms only compilation, not run-time playback/download.

## License

GPL-3.0-or-later project (compatible with NewPipeExtractor GPL-3.0). Respect licenses of NewPipeExtractor, AndroidX Media3, OkHttp and transitive dependencies. This project does not copy Snaptube proprietary APK, backend or classes.
