package pk.tearnova.medialab;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/** Visible, user-initiated foreground downloads with a persisted progress snapshot. */
public final class DownloadService extends Service {
    static final String PREFS = "media_lab_downloads";
    static final String EXTRA_URL = "media_url";
    static final String EXTRA_AUDIO = "audio_url";
    static final String EXTRA_TITLE = "media_title";
    static final String EXTRA_EXT = "media_ext";
    private static final String CHANNEL = "medialab_downloads";
    private static final String DONE_CHANNEL = "medialab_completed";
    private static final int ACTIVE_NOTIFICATION = 2401;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static volatile boolean active = false;
    private static volatile String activeVideoUrl = null;
    private static volatile String activeAudioUrl = null;
    static String activeStreamUrl(){ return activeVideoUrl; }
    static String activeAudioUrl(){ return activeAudioUrl; }
    static boolean isActive(){ return active; }
    private final AtomicBoolean running = new AtomicBoolean(false);
    private volatile long bytesDone = 0;
    private volatile long bytesTotal = -1;
    private volatile double speed = 0;
    private volatile String phase = "Starting";
    private volatile String title = "Media";
    private volatile String ext = "mp4";
    private long jobId;
    private long lastUpdate;
    private long sampleTime;
    private long sampleBytes;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        NotificationManager n = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        n.createNotificationChannel(new NotificationChannel(CHANNEL,"MediaLab downloads",NotificationManager.IMPORTANCE_LOW));
        n.createNotificationChannel(new NotificationChannel(DONE_CHANNEL,"MediaLab finished downloads",NotificationManager.IMPORTANCE_DEFAULT));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String url=intent.getStringExtra(EXTRA_URL);
        String audio=intent.getStringExtra(EXTRA_AUDIO);
        String incomingTitle=intent.getStringExtra(EXTRA_TITLE);
        String suffix=intent.getStringExtra(EXTRA_EXT);
        if (url==null || !url.startsWith("https://")) { stopSelfResult(startId); return START_NOT_STICKY; }
        if (!running.compareAndSet(false,true)) return START_NOT_STICKY;
        active=true;
        activeVideoUrl=url;
        activeAudioUrl=audio;
        title = incomingTitle == null ? "MediaLab download" : incomingTitle;
        ext = suffix == null ? "mp4" : suffix.replaceAll("[^a-zA-Z0-9]", "");
        if (ext.isEmpty()) ext="mp4";
        jobId=System.currentTimeMillis();
        phase="Connecting";
        bytesDone=0; bytesTotal=-1; speed=0;
        sampleTime=System.currentTimeMillis(); sampleBytes=0; lastUpdate=0;
        startForeground(ACTIVE_NOTIFICATION, notification(false,false));
        persist("running",null);
        executor.execute(()->runJob(url,audio,startId));
        return START_NOT_STICKY;
    }

    private void runJob(String videoUrl,String audioUrl,int startId) {
        File first=null,second=null,merged=null;
        try {
            File dir=new File(getCacheDir(),"media-lab-jobs");
            if(!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create temp directory");
            first=new File(dir,jobId+"_video.part");
            phase="Downloading video / audio";
            fetch(videoUrl,first);
            File finished=first;
            if(audioUrl!=null && !audioUrl.isEmpty()) {
                second=new File(dir,jobId+"_audio.part");
                phase="Downloading audio";
                bytesTotal=-1;
                fetch(audioUrl,second);
                phase="Merging MP4 + M4A";
                persist("merging",null);
                notifyUpdate();
                merged=new File(dir,jobId+"_merged.mp4");
                Mp4Joiner.merge(first,second,merged);
                finished=merged;
                ext="mp4";
            }
            phase="Saving to Downloads";
            persist("saving",null);
            Uri output=publish(finished, filename(title,jobId,ext),ext);
            phase="Downloaded";
            persist("completed",output.toString());
            addHistory(output.toString());
            notifyCompletion(true,null);
        } catch(Exception ex) {
            phase="Failed: "+safeError(ex);
            persist("failed",null);
            notifyCompletion(false,phase);
        } finally {
            if(first!=null) first.delete();
            if(second!=null) second.delete();
            if(merged!=null) merged.delete();
            running.set(false);
            active=false;
            activeVideoUrl=null;
            activeAudioUrl=null;
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelfResult(startId);
        }
    }

    private void fetch(String link,File destination) throws IOException {
        // Explicitly never follow non-HTTPS content downloads.
        if(!link.startsWith("https://")) throw new IOException("Only HTTPS media URLs are supported");
        HttpURLConnection conn=null;
        try {
            conn=(HttpURLConnection)new URL(link).openConnection();
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(30000);
            conn.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
            conn.setRequestProperty("Accept","*/*");
            conn.setInstanceFollowRedirects(true);
            int code=conn.getResponseCode();
            if(code<200 || code>=300) throw new IOException("Media server HTTP "+code);
            long length=conn.getContentLengthLong();
            if(length>0) bytesTotal = bytesTotal<0 ? bytesDone+length : bytesTotal+length;
            try(InputStream in=conn.getInputStream(); OutputStream out=new FileOutputStream(destination)) {
                byte[] buffer=new byte[128*1024];
                int read;
                while((read=in.read(buffer))!=-1) {
                    out.write(buffer,0,read);
                    bytesDone +=read;
                    updateProgress();
                }
                out.flush();
            }
        } finally { if(conn!=null) conn.disconnect(); }
    }

    private void updateProgress() {
        long now=System.currentTimeMillis();
        if(now-lastUpdate<800) return;
        long elapsed=now-sampleTime;
        if(elapsed>0) speed=(bytesDone-sampleBytes)*1000.0/elapsed;
        sampleBytes=bytesDone; sampleTime=now; lastUpdate=now;
        persist("running",null);
        notifyUpdate();
    }

    private Uri publish(File source,String outputName,String fileExt) throws IOException {
        String mime=(fileExt.equalsIgnoreCase("mp4")?"video/mp4":
                (fileExt.equalsIgnoreCase("m4a")?"audio/mp4":
                (fileExt.equalsIgnoreCase("webm")?"video/webm":
                (fileExt.equalsIgnoreCase("mp3")?"audio/mpeg":"application/octet-stream"))));
        if(Build.VERSION.SDK_INT>=29) {
            ContentValues cv=new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME,outputName);
            cv.put(MediaStore.MediaColumns.MIME_TYPE,mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/MediaLab");
            cv.put(MediaStore.MediaColumns.IS_PENDING,1);
            Uri result=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
            if(result==null) throw new IOException("Could not create Downloads entry");
            try(OutputStream output=getContentResolver().openOutputStream(result); InputStream input=new FileInputStream(source)) {
                if(output==null) throw new IOException("Could not open Downloads entry");
                byte[] b=new byte[128*1024]; int n;
                while((n=input.read(b))!=-1) output.write(b,0,n);
            } catch(Exception e) {
                getContentResolver().delete(result,null,null);
                throw new IOException("Save failed",e);
            }
            ContentValues ready=new ContentValues();
            ready.put(MediaStore.MediaColumns.IS_PENDING,0);
            getContentResolver().update(result,ready,null,null);
            return result;
        }
        File downloads=getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        if(downloads==null) throw new IOException("No storage directory");
        File out=new File(downloads,outputName);
        try(InputStream in=new FileInputStream(source);OutputStream os=new FileOutputStream(out)){
            byte[] b=new byte[128*1024];int n;
            while((n=in.read(b))!=-1) os.write(b,0,n);
        }
        MediaScannerConnection.scanFile(this,new String[]{out.getAbsolutePath()},new String[]{mime},null);
        return Uri.fromFile(out);
    }

    private void persist(String status,String fileUri) {
        try {
            JSONObject o=new JSONObject();
            o.put("id",jobId); o.put("title",title); o.put("phase",phase);
            o.put("status",status);o.put("done",bytesDone);o.put("total",bytesTotal);
            o.put("speed",speed);o.put("ext",ext);
            if(fileUri!=null) o.put("uri",fileUri);
            getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString("current",o.toString()).apply();
        } catch(Exception ignored) { }
    }

    private void addHistory(String uri) {
        SharedPreferences p=getSharedPreferences(PREFS,MODE_PRIVATE);
        try {
            JSONArray old=new JSONArray(p.getString("history","[]"));
            JSONArray newHistory=new JSONArray();
            JSONObject o=new JSONObject();o.put("title",title);o.put("uri",uri);o.put("ext",ext);o.put("date",System.currentTimeMillis());
            newHistory.put(o);
            for(int i=0;i<Math.min(19,old.length());i++) newHistory.put(old.getJSONObject(i));
            p.edit().putString("history",newHistory.toString()).apply();
        } catch(Exception ignored) { }
    }

    private Notification notification(boolean done,boolean failed) {
        int progress = bytesTotal>0 ? (int)Math.min(99,(bytesDone*100)/bytesTotal) : 0;
        Intent open=new Intent(this,MainActivity.class);
        open.putExtra("open_downloads",true);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder n=new Notification.Builder(this,CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(done?(failed?"MediaLab download failed":"MediaLab download complete"):title)
            .setContentText(done?(failed?phase:"Saved in Downloads / MediaLab"):(phase+" • "+human(bytesDone)+" • "+human((long)speed)+"/s"))
            .setContentIntent(pi)
            .setOnlyAlertOnce(!done)
            .setAutoCancel(done);
        if(!done) { n.setOngoing(true);n.setProgress(100,progress,bytesTotal<=0); }
        else {n.setSmallIcon(failed?android.R.drawable.stat_notify_error:android.R.drawable.stat_sys_download_done);}
        return n.build();
    }
    private void notifyUpdate(){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(ACTIVE_NOTIFICATION,notification(false,false));}
    private void notifyCompletion(boolean success,String error){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder n=new Notification.Builder(this,DONE_CHANNEL)
            .setSmallIcon(success?android.R.drawable.stat_sys_download_done:android.R.drawable.stat_notify_error)
            .setContentTitle(success?"MediaLab • Download complete":"MediaLab • Download failed")
            .setContentText(success?title:error)
            .setAutoCancel(true);
        Intent open=new Intent(this,MainActivity.class).putExtra("open_downloads",true);
        n.setContentIntent(PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
        nm.notify((int)(jobId%100000)+4000,n.build());
    }
    private static String filename(String name,long id,String ext){
        String safe=name==null?"MediaLab":name.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_").trim();
        if(safe.length()>64) safe=safe.substring(0,64);
        if(safe.isEmpty()) safe="MediaLab";
        return safe+"_"+id+"."+ext;
    }
    private static String safeError(Exception e){
        String s=e.getMessage();
        if(s==null) return e.getClass().getSimpleName();
        // Never put signed download URLs or their tokens into notification/log snapshots.
        s=s.replaceAll("https?://\\S+","[media server]");
        return s.length()>125?s.substring(0,125):s;
    }
    static String human(long bytes) {
        if(bytes<0) return "unknown";
        if(bytes<1024) return bytes+" B";
        double value=bytes/1024.0;String[] units={"KB","MB","GB","TB"};int i=0;
        while(value>=1024 && i<units.length-1){value/=1024;i++;}
        return new DecimalFormat("0.0").format(value)+" "+units[i];
    }
    @Override public void onDestroy(){executor.shutdownNow();super.onDestroy();}
}
