package pk.tearnova.medialab;

import android.net.Uri;
import android.text.Html;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Best-effort public-page metadata resolver. No private API, login cookie or token harvesting. */
final class InstagramPublicResolver {
    static final class Media {
        final String title;
        final String videoUrl;
        Media(String title, String videoUrl) { this.title=title;this.videoUrl=videoUrl; }
    }

    static boolean supports(String text) {
        try {
            Uri uri=Uri.parse(text);
            String host=uri.getHost();
            String path=uri.getPath();
            if(host==null || path==null || !"https".equalsIgnoreCase(uri.getScheme())) return false;
            host=host.toLowerCase(java.util.Locale.ROOT);
            if(!host.equals("instagram.com") && !host.equals("www.instagram.com") && !host.equals("m.instagram.com")) return false;
            return path.matches("^/(reel|p|tv)/[A-Za-z0-9_-]+/?$");
        } catch(Exception ignored) {return false;}
    }

    static Media inspect(String pageUrl) throws Exception {
        if(!supports(pageUrl)) throw new IllegalArgumentException("Use a public Instagram Reel or Post URL");
        Uri page=Uri.parse(pageUrl);
        String canonical="https://www.instagram.com"+page.getPath();
        HttpURLConnection c=(HttpURLConnection)new URL(canonical).openConnection();
        c.setConnectTimeout(16000);c.setReadTimeout(20000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36");
        c.setRequestProperty("Accept","text/html,application/xhtml+xml");
        c.setRequestProperty("Accept-Language","en-US,en;q=0.8");
        try {
            int code=c.getResponseCode();
            if(code==401||code==403||code==429)throw new IllegalStateException("Instagram requires login or blocks public metadata (HTTP "+code+")");
            if(code!=200)throw new IllegalStateException("Instagram page HTTP "+code);
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            try(InputStream input=c.getInputStream()) {
                byte[] buf=new byte[16384];int n;
                while((n=input.read(buf))!=-1 && bytes.size()<3_000_000) bytes.write(buf,0,n);
            }
            String html=bytes.toString(StandardCharsets.UTF_8.name());
            String title=findMeta(html,"og:title");
            String video=findMeta(html,"og:video:secure_url");
            if(video==null)video=findMeta(html,"og:video");
            if(video==null)video=findMeta(html,"twitter:player:stream");
            if(video==null)video=fromJson(html,"video_url");
            if(video==null)video=fromJson(html,"videoUrl");
            if(video==null||!video.startsWith("https://"))
                throw new IllegalStateException("Instagram did not expose a public video URL. Try a public Reel; no private or login-only content is supported.");
            String host=Uri.parse(video).getHost();
            if(host==null||host.isEmpty())throw new IllegalStateException("Invalid Instagram media URL");
            return new Media(title==null||title.isEmpty()?"Instagram Reel":title,video);
        } finally {c.disconnect();}
    }

    private static String findMeta(String html,String key){
        Pattern tags=Pattern.compile("<meta\\b[^>]*>",Pattern.CASE_INSENSITIVE);
        Matcher m=tags.matcher(html);
        while(m.find()){
            String tag=m.group();
            if(!tag.contains(key))continue;
            String property=attribute(tag,"property");
            String name=attribute(tag,"name");
            if(!key.equalsIgnoreCase(property)&&!key.equalsIgnoreCase(name))continue;
            String value=attribute(tag,"content");
            if(value!=null&&!value.isEmpty())return unescape(value);
        }
        return null;
    }
    private static String attribute(String tag,String key){
        Matcher m=Pattern.compile("\\b"+Pattern.quote(key)+"\\s*=\\s*([\"'])(.*?)\\1",Pattern.CASE_INSENSITIVE|Pattern.DOTALL).matcher(tag);
        return m.find()?m.group(2):null;
    }
    private static String fromJson(String html,String key){
        Matcher m=Pattern.compile("\\\""+Pattern.quote(key)+"\\\"\\s*:\\s*\\\"((?:\\\\.|[^\\\"\\\\])*)\\\"").matcher(html);
        if(!m.find())return null;
        try{return unescape(new org.json.JSONTokener("\""+m.group(1)+"\"").nextValue().toString());}
        catch(Exception e){return unescape(m.group(1).replace("\\/","/"));}
    }
    private static String unescape(String s){
        return Html.fromHtml(s,Html.FROM_HTML_MODE_LEGACY).toString().replace("\\/","/").replace("\\u0026","&");
    }
    private InstagramPublicResolver(){}
}
