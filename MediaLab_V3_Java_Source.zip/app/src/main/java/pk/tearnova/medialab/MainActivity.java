package pk.tearnova.medialab;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.MergingMediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.schabi.newpipe.extractor.MediaFormat;
import org.schabi.newpipe.extractor.NewPipe;
import org.schabi.newpipe.extractor.stream.AudioStream;
import org.schabi.newpipe.extractor.stream.DeliveryMethod;
import org.schabi.newpipe.extractor.stream.Stream;
import org.schabi.newpipe.extractor.stream.StreamInfo;
import org.schabi.newpipe.extractor.stream.VideoStream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** MediaLab V3: clean native UI; only public/authorized media; no private APIs or accounts. */
public final class MainActivity extends Activity {
    private static final int NOTIFICATION_REQUEST=92;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ArrayList<Choice> choices=new ArrayList<>();
    private FrameLayout root;
    private LinearLayout shell,body,bottomBar,lastColumn,downloadsPanel;
    private View loader;
    private EditText urlField;
    private ExoPlayer player;
    private Dialog activeSheet;
    private boolean muted=false, inspecting=false, resumed=false;
    private String enteredUrl="",title="Media",currentPage="home";
    private int lInset=-1,tInset=-1,rInset=-1,bInset=-1;
    private final Runnable refresh=new Runnable(){
        @Override public void run(){
            if(resumed && currentPage.equals("downloads"))refreshDownloads();
            ui.postDelayed(this,1000);
        }
    };

    private static final class Choice {
        final String label,ext,url,audio;
        Choice(String label,String ext,String url,String audio){this.label=label;this.ext=ext;this.url=url;this.audio=audio;}
        boolean hasVideo(){return ext.equals("mp4")||ext.equals("webm");}
    }

    @Override public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Palette.BG);
        getWindow().setNavigationBarColor(Palette.BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        NewPipe.init(new HttpExtractorDownloader(s->Log.d("MediaLab", s)));
        setupShell();showHome();ui.postDelayed(refresh,1000);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_REQUEST);
        handleIntent(getIntent());
    }
    @Override protected void onResume(){super.onResume();resumed=true;}
    @Override protected void onPause(){resumed=false;super.onPause();}
    @Override public void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);handleIntent(intent);}
    private void handleIntent(Intent intent){
        if(intent==null)return;
        if(intent.getBooleanExtra("open_downloads",false)) {showDownloads();return;}
        if(Intent.ACTION_SEND.equals(intent.getAction())&&"text/plain".equals(intent.getType())){
            String link=extractUrl(intent.getStringExtra(Intent.EXTRA_TEXT));
            if(link==null){toast("Shared text contains no HTTP link");return;}
            enteredUrl=link;
            if(urlField!=null)urlField.setText(link);
            ui.post(()->sharedSheet(link));
        }
    }
    private String extractUrl(String text){
        if(text==null)return null;
        Matcher m=Pattern.compile("https?://[^\\s<>]+",Pattern.CASE_INSENSITIVE).matcher(text);
        return m.find()?m.group().replaceAll("[.,;!]+$",""):null;
    }
    private int dp(int n){return Palette.dp(this,n);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void setupShell(){
        root=new FrameLayout(this);root.setBackgroundColor(Palette.BG);
        shell=Palette.vertical(this);
        root.addView(shell,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets safe=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                applyInsets(safe.left,safe.top,safe.right,safe.bottom);
            }else applyInsets(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        LinearLayout header=Palette.horizontal(this);
        header.setPadding(dp(21),dp(12),dp(18),dp(12));
        header.addView(Palette.text(this,"MediaLab",22,Palette.WHITE,true));
        shell.addView(header,new LinearLayout.LayoutParams(-1,dp(60)));
        View line=new View(this);line.setBackgroundColor(Palette.SURFACE);
        shell.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        body=Palette.vertical(this);
        shell.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        bottomBar=Palette.horizontal(this);
        bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setBackgroundColor(Palette.PANEL);
        bottomBar.setPadding(0,dp(7),0,dp(7));
        shell.addView(bottomBar,new LinearLayout.LayoutParams(-1,dp(72)));
    }
    private void applyInsets(int l,int t,int r,int b){
        if(l==lInset&&t==tInset&&r==rInset&&b==bInset)return;
        lInset=l;tInset=t;rInset=r;bInset=b;
        root.setPadding(l,t,r,b);
    }
    private void nav(){
        bottomBar.removeAllViews();
        navIcon(R.drawable.ic_nav_home,"Home",currentPage.equals("home")||currentPage.equals("details"),this::showHome);
        navIcon(R.drawable.ic_nav_downloads,"Downloads",currentPage.equals("downloads")||currentPage.equals("playing"),this::showDownloads);
    }
    private void navIcon(int drawable,String description,boolean selected,Runnable click){
        FrameLayout touch=new FrameLayout(this);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(96),dp(54));
        p.leftMargin=dp(9);p.rightMargin=dp(9);bottomBar.addView(touch,p);
        if(selected)touch.setBackground(Palette.bg(this,Palette.SURFACE,18));
        ImageView icon=new ImageView(this);
        icon.setImageResource(drawable);
        icon.setImageTintList(ColorStateList.valueOf(selected?Palette.MINT:Palette.MUTED));
        icon.setContentDescription(description);
        touch.addView(icon,new FrameLayout.LayoutParams(dp(32),dp(32),Gravity.CENTER));
        touch.setOnClickListener(v->click.run());
    }
    private void scrollPage(){
        body.removeAllViews();
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        LinearLayout col=Palette.vertical(this);
        col.setPadding(dp(18),dp(19),dp(18),dp(25));
        scroll.addView(col);body.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        lastColumn=col;
    }
    private void showHome(){
        releasePlayer();currentPage="home";nav();scrollPage();downloadsPanel=null;
        LinearLayout card=Palette.vertical(this);
        card.setPadding(dp(15),dp(15),dp(15),dp(17));
        card.setBackground(Palette.bg(this,Palette.PANEL,18));
        lastColumn.addView(card,Palette.lp(this,-1,-2,14));
        urlField=new EditText(this);
        urlField.setSingleLine(false);urlField.setMinLines(2);urlField.setMaxLines(3);
        urlField.setTextSize(15);urlField.setTextColor(Palette.WHITE);urlField.setHintTextColor(Palette.MUTED);
        urlField.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);
        urlField.setHint("Paste YouTube or Instagram URL");urlField.setText(enteredUrl);
        urlField.setBackground(Palette.bg(this,Palette.SURFACE,12));
        urlField.setPadding(dp(15),dp(13),dp(15),dp(13));
        card.addView(urlField,Palette.lp(this,-1,-2,0));
        Button download=Palette.button(this,"Download",true);
        lastColumn.addView(download,Palette.lp(this,-1,dp(54),17));
        download.setOnClickListener(v->{
            String candidate=extractUrl(urlField.getText().toString().trim());
            if(candidate==null){toast("Paste a valid video URL");return;}
            enteredUrl=candidate;inspect(candidate,false);
        });
    }
    private void inspect(String link,boolean showSheetAfter){
        if(inspecting){toast("Already checking a link");return;}
        inspecting=true;enteredUrl=link;showLoader();
        long started=SystemClock.elapsedRealtime();
        worker.execute(()->{
            Exception error=null;String resolvedTitle="Media";
            ArrayList<Choice> found=new ArrayList<>();
            try{
                if(InstagramPublicResolver.supports(link)){
                    InstagramPublicResolver.Media reel=InstagramPublicResolver.inspect(link);
                    resolvedTitle=reel.title;
                    found.add(new Choice("MP4 • Instagram video","mp4",reel.videoUrl,null));
                }else{
                    StreamInfo info=StreamInfo.getInfo(link);
                    resolvedTitle=info.getName()==null?"Video":info.getName();
                    found.addAll(youtubeChoices(info));
                    if(found.isEmpty())throw new IllegalStateException("No compatible video-with-audio streams were returned");
                }
            }catch(Exception e){error=e;}
            final Exception failure=error;final String finalTitle=resolvedTitle;
            long delay=Math.max(0,5000-(SystemClock.elapsedRealtime()-started));
            ui.postDelayed(()->{
                hideLoader();inspecting=false;
                if(failure!=null){errorSheet(cleanError(failure));return;}
                title=finalTitle;choices.clear();choices.addAll(found);
                showDetails();
                if(showSheetAfter)ui.postDelayed(this::qualitySheet,350);
            },delay);
        });
    }
    private ArrayList<Choice> youtubeChoices(StreamInfo info){
        ArrayList<Choice> result=new ArrayList<>();
        List<AudioStream> audios=info.getAudioStreams();
        AudioStream bestAac=null;
        for(AudioStream a:audios){
            if(usable(a)&&"m4a".equals(ext(a,"m4a")) && (bestAac==null||a.getAverageBitrate()>bestAac.getAverageBitrate()))bestAac=a;
        }
        List<VideoStream> complete=new ArrayList<>(info.getVideoStreams());
        complete.sort((a,b)->Integer.compare(res(b),res(a)));
        for(VideoStream v:complete){
            if(!usable(v))continue;
            String extension=ext(v,"mp4");
            if(!extension.equals("mp4")&&!extension.equals("webm"))continue;
            result.add(new Choice(v.getResolution()+" • "+extension.toUpperCase(Locale.ROOT),extension,v.getContent(),null));
        }
        List<VideoStream> split=new ArrayList<>(info.getVideoOnlyStreams());
        split.sort((a,b)->Integer.compare(res(b),res(a)));
        for(VideoStream v:split){
            if(!usable(v)||!"mp4".equals(ext(v,"mp4"))||bestAac==null)continue;
            result.add(new Choice(v.getResolution()+" • MP4","mp4",v.getContent(),bestAac.getContent()));
        }
        for(AudioStream a:audios){
            if(!usable(a))continue;
            String extension=ext(a,"m4a");
            if(!extension.equals("m4a")&&!extension.equals("webm"))continue;
            result.add(new Choice("Audio • "+Math.max(0,a.getAverageBitrate())+" kbps",extension,a.getContent(),null));
        }
        return result;
    }
    private boolean usable(Stream s){return s!=null&&s.isUrl()&&s.getContent().startsWith("https://")&&s.getDeliveryMethod()==DeliveryMethod.PROGRESSIVE_HTTP;}
    private String ext(Stream s,String fallback){
        MediaFormat f=s.getFormat();String extension=f==null?null:f.getSuffix();
        return extension==null?fallback:extension.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");
    }
    private int res(VideoStream s){
        try{Matcher m=Pattern.compile("(\\d+)").matcher(s.getResolution());return m.find()?Integer.parseInt(m.group(1)):0;}
        catch(Exception e){return 0;}
    }
    private void showDetails(){
        currentPage="details";nav();scrollPage();
        Choice preview=null;
        for(Choice c:choices)if(c.hasVideo()){preview=c;break;}
        if(preview!=null)playerCard(preview.url,preview.audio,"Preview");
        lastColumn.addView(Palette.text(this,title,19,Palette.WHITE,true),Palette.lp(this,-1,-2,16));
        Button choose=Palette.button(this,"Select quality",true);
        lastColumn.addView(choose,Palette.lp(this,-1,dp(52),18));choose.setOnClickListener(v->qualitySheet());
        for(Choice c:choices)lastColumn.addView(qualityRow(c,false),Palette.lp(this,-1,-2,10));
    }
    private void playerCard(String videoUrl,String audioUrl,String heading){
        FrameLayout holder=new FrameLayout(this);holder.setBackground(Palette.bg(this,Palette.BLACK,16));
        lastColumn.addView(holder,Palette.lp(this,-1,dp(245),6));
        PlayerView view=new PlayerView(this);
        view.setUseController(true);
        view.setControllerShowTimeoutMs(4000);
        holder.addView(view,new FrameLayout.LayoutParams(-1,-1));
        TextView mute=Palette.text(this,"Volume on",13,Palette.WHITE,true);
        mute.setGravity(Gravity.CENTER);
        mute.setPadding(dp(12),dp(8),dp(12),dp(8));
        mute.setBackground(Palette.bg(this,0xCC172339,13));
        FrameLayout.LayoutParams mp=new FrameLayout.LayoutParams(dp(107),dp(44),Gravity.TOP|Gravity.END);
        mp.setMargins(0,dp(12),dp(12),0);
        holder.addView(mute,mp);
        mute.setOnClickListener(v->{
            muted=!muted;
            if(player!=null)player.setVolume(muted?0f:1f);
            mute.setText(muted?"Unmute":"Volume on");
        });
        if(videoUrl==null||videoUrl.isEmpty()){toast("No preview stream");return;}
        releasePlayer();
        try{
            DefaultHttpDataSource.Factory http=new DefaultHttpDataSource.Factory()
                .setUserAgent("Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                .setAllowCrossProtocolRedirects(false);
            DefaultDataSource.Factory data=new DefaultDataSource.Factory(this,http);
            ProgressiveMediaSource.Factory factory=new ProgressiveMediaSource.Factory(data);
            MediaSource video=factory.createMediaSource(MediaItem.fromUri(Uri.parse(videoUrl)));
            player=new ExoPlayer.Builder(this).build();
            if(audioUrl!=null&&!audioUrl.isEmpty()){
                MediaSource audio=factory.createMediaSource(MediaItem.fromUri(Uri.parse(audioUrl)));
                player.setMediaSource(new MergingMediaSource(true,true,video,audio));
            }else player.setMediaSource(video);
            player.setVolume(muted?0f:1f);
            view.setPlayer(player);
            player.addListener(new Player.Listener(){
                @Override public void onPlayerError(PlaybackException error){
                    toast("Streaming unavailable: "+cleanError(error));
                }
            });
            player.prepare();player.play();
        }catch(Exception ex){toast("Cannot start stream: "+cleanError(ex));}
    }
    private View qualityRow(Choice c,boolean sheetMode){
        LinearLayout row=Palette.horizontal(this);row.setBackground(Palette.bg(this,Palette.PANEL,15));
        row.setPadding(dp(15),dp(11),dp(11),dp(11));
        TextView label=Palette.text(this,c.label,15,Palette.WHITE,true);
        row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        Button button=Palette.button(this,"Save",true);
        row.addView(button,new LinearLayout.LayoutParams(dp(78),dp(42)));
        button.setOnClickListener(v->{
            if(activeSheet!=null && sheetMode){activeSheet.dismiss();activeSheet=null;}
            beginDownload(c);
        });
        return row;
    }
    private Dialog sheet(LinearLayout content){
        Dialog d=new Dialog(this);
        content.setBackground(Palette.bg(this,Palette.PANEL,24));
        content.setPadding(dp(18),dp(19),dp(18),dp(28));
        d.setContentView(content);
        Window w=d.getWindow();
        if(w!=null){
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams p=w.getAttributes();
            p.width=-1;p.height=-2;p.gravity=Gravity.BOTTOM;p.dimAmount=.57f;
            p.windowAnimations=android.R.style.Animation_Dialog;w.setAttributes(p);
        }
        return d;
    }
    private void displaySheet(Dialog d){
        d.show();Window w=d.getWindow();
        if(w!=null){w.setLayout(-1,-2);w.setGravity(Gravity.BOTTOM);w.setNavigationBarColor(Palette.PANEL);}
    }
    private void sharedSheet(String shared){
        if(isFinishing()||isDestroyed())return;
        if(activeSheet!=null)activeSheet.dismiss();
        LinearLayout content=Palette.vertical(this);
        content.addView(Palette.text(this,"Shared link",23,Palette.WHITE,true));
        content.addView(Palette.text(this,shared.length()>110?shared.substring(0,110)+"...":shared,12,Palette.MUTED,false),Palette.lp(this,-1,-2,12));
        Button action=Palette.button(this,"Download",true);
        content.addView(action,Palette.lp(this,-1,dp(52),17));
        Dialog dialog=sheet(content);activeSheet=dialog;
        action.setOnClickListener(v->{dialog.dismiss();activeSheet=null;inspect(shared,true);});
        displaySheet(dialog);
    }
    private void qualitySheet(){
        if(isFinishing())return;
        if(activeSheet!=null)activeSheet.dismiss();
        LinearLayout content=Palette.vertical(this);
        content.addView(Palette.text(this,"Choose quality",22,Palette.WHITE,true));
        ScrollView scroll=new ScrollView(this);
        LinearLayout options=Palette.vertical(this);
        for(Choice c:choices)options.addView(qualityRow(c,true),Palette.lp(this,-1,-2,9));
        if(choices.isEmpty())options.addView(Palette.text(this,"No formats available",14,Palette.WARNING,false));
        scroll.addView(options);content.addView(scroll,Palette.lp(this,-1,dp(400),12));
        Dialog dialog=sheet(content);activeSheet=dialog;displaySheet(dialog);
    }
    private void errorSheet(String error){
        LinearLayout content=Palette.vertical(this);
        content.addView(Palette.text(this,"Could not load video",22,Palette.WHITE,true));
        content.addView(Palette.text(this,error,13,Palette.MUTED,false),Palette.lp(this,-1,-2,12));
        Button dismiss=Palette.button(this,"OK",true);
        content.addView(dismiss,Palette.lp(this,-1,dp(50),18));
        Dialog d=sheet(content);activeSheet=d;
        dismiss.setOnClickListener(v->{d.dismiss();activeSheet=null;});displaySheet(d);
    }
    private void beginDownload(Choice c){
        if(DownloadService.isActive()){toast("A download is already running");showDownloads();return;}
        Intent i=new Intent(this,DownloadService.class);
        i.putExtra(DownloadService.EXTRA_URL,c.url);
        i.putExtra(DownloadService.EXTRA_AUDIO,c.audio);
        i.putExtra(DownloadService.EXTRA_TITLE,title);
        i.putExtra(DownloadService.EXTRA_EXT,c.ext);
        try{startForegroundService(i);showDownloads();}
        catch(Exception e){toast("Download service error: "+cleanError(e));}
    }
    private void showDownloads(){
        releasePlayer();currentPage="downloads";nav();scrollPage();
        lastColumn.addView(Palette.text(this,"Downloads",26,Palette.WHITE,true),Palette.lp(this,-1,-2,5));
        downloadsPanel=Palette.vertical(this);
        lastColumn.addView(downloadsPanel,Palette.lp(this,-1,-2,18));refreshDownloads();
    }
    private void refreshDownloads(){
        if(downloadsPanel==null || !currentPage.equals("downloads"))return;
        downloadsPanel.removeAllViews();
        android.content.SharedPreferences prefs=getSharedPreferences(DownloadService.PREFS,MODE_PRIVATE);
        try{
            String raw=prefs.getString("current","");
            if(!raw.isEmpty()){
                JSONObject c=new JSONObject(raw);
                String state=c.optString("status","");
                LinearLayout card=Palette.vertical(this);
                card.setBackground(Palette.bg(this,Palette.PANEL,16));
                card.setPadding(dp(16),dp(16),dp(16),dp(16));
                downloadsPanel.addView(card);
                card.addView(Palette.text(this,state.equals("completed")?"COMPLETED":state.equals("failed")?"FAILED":"IN PROGRESS",12,state.equals("failed")?Palette.WARNING:Palette.MINT,true));
                card.addView(Palette.text(this,c.optString("title","Media"),16,Palette.WHITE,true),Palette.lp(this,-1,-2,9));
                card.addView(Palette.text(this,c.optString("phase","Preparing"),12,Palette.MUTED,false),Palette.lp(this,-1,-2,5));
                long done=c.optLong("done",0),total=c.optLong("total",-1);
                int progress=total>0?(int)Math.min(100,done*100/total):0;
                ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
                bar.setMax(100);bar.setProgress(progress);bar.setIndeterminate(total<=0&&!state.equals("completed")&&!state.equals("failed"));
                bar.setProgressTintList(ColorStateList.valueOf(Palette.MINT));
                card.addView(bar,Palette.lp(this,-1,dp(9),14));
                card.addView(Palette.text(this,progress+"%  •  "+DownloadService.human(done)+" / "+DownloadService.human(total),14,Palette.WHITE,true),Palette.lp(this,-1,-2,13));
                card.addView(Palette.text(this,"Remaining: "+DownloadService.human(total>0?Math.max(0,total-done):-1),13,Palette.MUTED,false),Palette.lp(this,-1,-2,6));
                card.addView(Palette.text(this,"Speed: "+DownloadService.human((long)c.optDouble("speed",0))+"/s",14,Palette.MINT,true),Palette.lp(this,-1,-2,7));
                if((state.equals("running")||state.equals("merging")) && progress>=8 && DownloadService.isActive()){
                    String stream=DownloadService.activeStreamUrl();String audio=DownloadService.activeAudioUrl();
                    if(stream!=null && !stream.isEmpty()){
                        Button ready=Palette.button(this,"Ready to play",true);
                        card.addView(ready,Palette.lp(this,-1,dp(48),15));
                        ready.setOnClickListener(v->playDownloadStream(stream,audio));
                    }
                }
                if(state.equals("completed")&&c.has("uri")){
                    Button play=Palette.button(this,"Play",true);
                    card.addView(play,Palette.lp(this,-1,dp(46),15));
                    String uri=c.optString("uri","");
                    play.setOnClickListener(v->playSaved(uri));
                }
            }
            JSONArray history=new JSONArray(prefs.getString("history","[]"));
            if(history.length()>0) downloadsPanel.addView(Palette.text(this,"Recent",18,Palette.WHITE,true),Palette.lp(this,-1,-2,19));
            for(int j=0;j<history.length();j++){
                JSONObject item=history.optJSONObject(j);if(item==null)continue;
                LinearLayout row=Palette.horizontal(this);row.setBackground(Palette.bg(this,Palette.PANEL,13));
                row.setPadding(dp(13),dp(10),dp(10),dp(10));
                TextView label=Palette.text(this,item.optString("title","Saved media"),13,Palette.WHITE,false);
                row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
                Button play=Palette.button(this,"Play",false);
                row.addView(play,new LinearLayout.LayoutParams(dp(76),dp(42)));
                String saved=item.optString("uri","");play.setOnClickListener(v->playSaved(saved));
                downloadsPanel.addView(row,Palette.lp(this,-1,-2,9));
            }
            if(raw.isEmpty()&&history.length()==0)
                downloadsPanel.addView(Palette.text(this,"No downloads yet",15,Palette.MUTED,false));
        }catch(Exception e){downloadsPanel.addView(Palette.text(this,"Unable to read download history",14,Palette.WARNING,false));}
    }
    private void playSaved(String uri){
        if(uri==null||uri.isEmpty()){toast("Saved file unavailable");return;}
        openPlaying(uri,null,"Saved media");
    }
    private void playDownloadStream(String video,String audio){openPlaying(video,audio,"Ready to play");}
    private void openPlaying(String video,String audio,String heading){
        currentPage="playing";nav();scrollPage();
        lastColumn.addView(Palette.text(this,heading,23,Palette.WHITE,true));
        playerCard(video,audio,heading);
        Button back=Palette.button(this,"Back to downloads",false);
        lastColumn.addView(back,Palette.lp(this,-1,dp(50),15));back.setOnClickListener(v->showDownloads());
    }
    private String cleanError(Exception ex){
        String raw=ex.getMessage();
        if(raw==null)raw=ex.getClass().getSimpleName();
        raw=raw.replaceAll("https?://[^\\s\"'<>]+","[media URL]")
            .replaceAll("(?i)(cookie|authorization|token|signature)[=:]\\S+","[credential hidden]");
        return raw.length()>200?raw.substring(0,200):raw;
    }
    private void showLoader(){
        if(loader!=null)root.removeView(loader);
        FrameLayout shade=new FrameLayout(this);shade.setBackgroundColor(0xE9091122);
        LinearLayout center=Palette.vertical(this);center.setGravity(Gravity.CENTER);
        center.setPadding(dp(25),dp(24),dp(25),dp(24));center.setBackground(Palette.bg(this,Palette.PANEL,22));
        ProgressBar spin=new ProgressBar(this);spin.setIndeterminateTintList(ColorStateList.valueOf(Palette.MINT));
        center.addView(spin,new LinearLayout.LayoutParams(dp(56),dp(56)));
        TextView message=Palette.text(this,"Preparing video…",16,Palette.WHITE,true);
        message.setGravity(Gravity.CENTER);center.addView(message,Palette.lp(this,-1,-2,20));
        shade.addView(center,new FrameLayout.LayoutParams(dp(282),-2,Gravity.CENTER));
        root.addView(shade,new FrameLayout.LayoutParams(-1,-1));loader=shade;
    }
    private void hideLoader(){if(loader!=null){root.removeView(loader);loader=null;}}
    private void releasePlayer(){
        if(player!=null){try{player.stop();player.release();}catch(Exception ignored){}player=null;}
    }
    @Override public void onBackPressed(){
        if(currentPage.equals("details")||currentPage.equals("downloads"))showHome();
        else if(currentPage.equals("playing"))showDownloads();
        else super.onBackPressed();
    }
    @Override public void onDestroy(){
        resumed=false;ui.removeCallbacks(refresh);releasePlayer();worker.shutdownNow();super.onDestroy();
    }
}
