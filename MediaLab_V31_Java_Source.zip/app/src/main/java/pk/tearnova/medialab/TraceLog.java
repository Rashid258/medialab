package pk.tearnova.medialab;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Diagnostic messages ONLY. Never include the actual signed media URL or request credentials. */
final class TraceLog {
    private static final Object LOCK=new Object();
    private static final String PREF="medialab_trace";
    private static String redact(String s){
        if(s==null)return "unknown";
        s=s.replaceAll("https?://[^\\s\\\"'<>]+","[media URL]");
        s=s.replaceAll("(?i)(cookie|authorization|token|signature|key)[=:]\\S+","[redacted]");
        if(s.length()>320)s=s.substring(0,320);
        return s;
    }
    static void add(Context c,String text){
        String safe=redact(text);
        Log.i("MediaLab",safe);
        synchronized(LOCK){
            String old=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("lines","");
            if(old.length()>26000)old=old.substring(old.length()-22000);
            String line=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date())+"  "+safe+"\n";
            c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("lines",old+line).apply();
        }
    }
    static Uri export(Context c)throws IOException{
        String body="MediaLab V3.1 safe diagnostics\n"+c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("lines", "No diagnostic entries yet.\n");
        ContentValues cv=new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME,"MediaLab_Trace_"+System.currentTimeMillis()+".txt");
        cv.put(MediaStore.MediaColumns.MIME_TYPE,"text/plain");
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/MediaLab");
        cv.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri uri=c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
        if(uri==null)throw new IOException("Cannot create diagnostic file");
        try(OutputStream out=c.getContentResolver().openOutputStream(uri,"w")){
            if(out==null)throw new IOException("Cannot open diagnostic file");
            out.write(body.getBytes(StandardCharsets.UTF_8));
        }catch(Exception ex){c.getContentResolver().delete(uri,null,null);throw new IOException("Cannot write diagnostic file",ex);}
        ContentValues ready=new ContentValues();ready.put(MediaStore.MediaColumns.IS_PENDING,0);
        if(c.getContentResolver().update(uri,ready,null,null)<1)throw new IOException("Cannot publish diagnostics");
        return uri;
    }
    private TraceLog(){}
}
