package pk.tearnova.medialab;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** HTTP Range validation shared by downloader and standalone regression tests. */
final class ResumePolicy {
    private static final Pattern PARTIAL=Pattern.compile("bytes (\\d+)-(\\d+)/(\\d+|\\*)",Pattern.CASE_INSENSITIVE);
    private static final Pattern UNSAT=Pattern.compile("bytes \\*/(\\d+)",Pattern.CASE_INSENSITIVE);

    static long totalOf206(String contentRange,long expectedStart)throws IOException {
        Matcher m=PARTIAL.matcher(contentRange==null?"":contentRange);
        if(!m.matches())throw new IOException("Missing or invalid Content-Range");
        long start=Long.parseLong(m.group(1));
        long end=Long.parseLong(m.group(2));
        if(start!=expectedStart||end<start)throw new IOException("Resume range does not match requested offset");
        if("*".equals(m.group(3)))return -1;
        long total=Long.parseLong(m.group(3));
        if(total<=end)throw new IOException("Content-Range total is inconsistent");
        return total;
    }
    static boolean isComplete416(String contentRange,long localBytes) {
        Matcher m=UNSAT.matcher(contentRange==null?"":contentRange);
        if(!m.matches()||localBytes<=0)return false;
        try{return Long.parseLong(m.group(1))==localBytes;}
        catch(NumberFormatException ignored){return false;}
    }
    private ResumePolicy(){}
}
