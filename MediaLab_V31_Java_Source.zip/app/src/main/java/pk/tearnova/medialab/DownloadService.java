package pk.tearnova.medialab;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Persistent per-job downloader; at most two simultaneous transfers and independent controls. */
public final class DownloadService extends Service {
    static final String PREFS = "media_lab_downloads";
    static final String EXTRA_URL = "media_url";
    static final String EXTRA_AUDIO = "audio_url";
    static final String EXTRA_TITLE = "media_title";
    static final String EXTRA_EXT = "media_ext";
    static final String EXTRA_ID = "job_id";
    static final String EXTRA_IS_VIDEO = "is_video";
    static final String EXTRA_EXPECT_AUDIO = "expect_audio";
    static final String ACTION_ADD = "pk.tearnova.medialab.ADD";
    static final String ACTION_PAUSE = "pk.tearnova.medialab.PAUSE";
    static final String ACTION_RESUME = "pk.tearnova.medialab.RESUME";
    static final String ACTION_CANCEL = "pk.tearnova.medialab.CANCEL";
    static final String ACTION_RETRY = "pk.tearnova.medialab.RETRY";
    private static final String CHANNEL="medialab_downloads_v31";
    private static final String DONE_CHANNEL="medialab_finished_v31";
    private static final int FOREGROUND_ID=2401;
    private static final int BUFFER=64*1024;
    private static final long SPACE_RESERVE=16L*1024*1024;
    private final ExecutorService workers=Executors.newFixedThreadPool(2);
    private final Object lock=new Object();
    private final LinkedHashMap<String,Job> jobs=new LinkedHashMap<>();
    private final Map<String,Control> controls=new ConcurrentHashMap<>();
    private NotificationManager notifications;
    private boolean foreground;
    private volatile int newestStartId;

    private static final class Control {
        volatile boolean pause;
        volatile boolean cancel;
        volatile boolean resumeAfterStop;
        volatile HttpURLConnection connection;
    }
    private static final class Halt extends IOException {
        Halt(String reason){super(reason);}
    }
    private static final class HttpFailure extends IOException {
        final int code;
        HttpFailure(int c){super("Media server HTTP "+c);code=c;}
    }
    private static final class Job {
        String id,url,audio,title,ext,status="queued",phase="Queued",uri="";
        boolean isVideo=true,expectAudio=true;
        String videoEtag="",audioEtag="",videoModified="",audioModified="",error="";
        long videoBytes=0,audioBytes=0,videoTotal=-1,audioTotal=-1,updated=0;
        double speed=0;
        int attempts=0;
        JSONObject json() throws JSONException {
            JSONObject v=new JSONObject();
            v.put("id",id);v.put("url",url);v.put("audio",audio);v.put("title",title);v.put("ext",ext);
            v.put("status",status);v.put("phase",phase);v.put("uri",uri);
            v.put("isVideo",isVideo);v.put("expectAudio",expectAudio);
            v.put("videoBytes",videoBytes);v.put("audioBytes",audioBytes);
            v.put("videoTotal",videoTotal);v.put("audioTotal",audioTotal);
            v.put("videoEtag",videoEtag);v.put("audioEtag",audioEtag);
            v.put("videoModified",videoModified);v.put("audioModified",audioModified);
            v.put("error",error);v.put("speed",speed);v.put("attempts",attempts);
            v.put("updated",updated);
            return v;
        }
        static Job from(JSONObject v) {
            Job j=new Job();
            j.id=v.optString("id",UUID.randomUUID().toString());j.url=v.optString("url","");
            j.audio=v.optString("audio","");j.title=v.optString("title","Media");
            j.ext=v.optString("ext","mp4");j.status=v.optString("status","paused");
            j.phase=v.optString("phase","Paused");j.uri=v.optString("uri","");
            j.isVideo=v.optBoolean("isVideo",!j.ext.equals("m4a"));j.expectAudio=v.optBoolean("expectAudio",true);
            j.videoBytes=v.optLong("videoBytes",0);j.audioBytes=v.optLong("audioBytes",0);
            j.videoTotal=v.optLong("videoTotal",-1);j.audioTotal=v.optLong("audioTotal",-1);
            j.videoEtag=v.optString("videoEtag","");j.audioEtag=v.optString("audioEtag","");
            j.videoModified=v.optString("videoModified","");j.audioModified=v.optString("audioModified","");
            j.error=v.optString("error","");j.speed=v.optDouble("speed",0);
            j.attempts=v.optInt("attempts",0);j.updated=v.optLong("updated",0);
            return j;
        }
        long done(){return videoBytes+audioBytes;}
        long total(){return videoTotal>=0 && (audio.isEmpty()||audioTotal>=0) ? videoTotal+(audio.isEmpty()?0:audioTotal):-1;}
    }

    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onCreate(){
        super.onCreate();
        notifications=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        notifications.createNotificationChannel(new NotificationChannel(CHANNEL,"MediaLab active downloads",NotificationManager.IMPORTANCE_LOW));
        notifications.createNotificationChannel(new NotificationChannel(DONE_CHANNEL,"MediaLab finished downloads",NotificationManager.IMPORTANCE_DEFAULT));
        synchronized(lock){
            try{
                JSONArray raw=new JSONArray(getSharedPreferences(PREFS,MODE_PRIVATE).getString("jobs","[]"));
                for(int i=0;i<raw.length();i++){
                    JSONObject item=raw.optJSONObject(i);if(item==null)continue;
                    Job j=Job.from(item);
                    if(j.status.equals("running")||j.status.equals("queued")||j.status.equals("merging")||j.status.equals("saving")||j.status.equals("verifying")){
                        j.status="paused";j.phase="Interrupted — tap Resume";
                    }
                    jobs.put(j.id,j);
                }
            }catch(Exception ignored){}
            saveLocked();
        }
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        newestStartId=startId;
        if(intent==null){stopIfIdle();return START_NOT_STICKY;}
        String action=intent.getAction();
        if(action==null || action.equals(ACTION_ADD)){
            String url=intent.getStringExtra(EXTRA_URL);
            String audio=intent.getStringExtra(EXTRA_AUDIO);
            if(!https(url) || (audio!=null&&!audio.isEmpty()&&!https(audio))){stopIfIdle();return START_NOT_STICKY;}
            Job j=new Job();j.id=UUID.randomUUID().toString();j.url=url;j.audio=audio==null?"":audio;
            j.title=intent.getStringExtra(EXTRA_TITLE);if(j.title==null)j.title="MediaLab download";
            String ext=intent.getStringExtra(EXTRA_EXT);j.ext=ext==null?"mp4":ext.replaceAll("[^a-zA-Z0-9]","").toLowerCase(Locale.ROOT);
            if(j.ext.isEmpty())j.ext="mp4";
            j.isVideo=intent.getBooleanExtra(EXTRA_IS_VIDEO,!j.ext.equals("m4a"));
            j.expectAudio=intent.getBooleanExtra(EXTRA_EXPECT_AUDIO,true);
            synchronized(lock){jobs.put(j.id,j);saveLocked();}
            TraceLog.add(this,"Queued job "+j.id.substring(0,8)+" "+(j.isVideo?"video":"audio"));
            schedule(j);
        }else {
            String id=intent.getStringExtra(EXTRA_ID);
            if(id!=null)command(action,id);
        }
        stopIfIdle();
        return START_NOT_STICKY;
    }
    private static boolean https(String v){return v!=null&&v.startsWith("https://");}
    private void ensureForeground(){
        if(!foreground){startForeground(FOREGROUND_ID,summary());foreground=true;}
        else notifications.notify(FOREGROUND_ID,summary());
    }
    private Notification summary(){
        Intent open=new Intent(this,MainActivity.class).putExtra("open_downloads",true);
        PendingIntent p=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("MediaLab downloads").setContentText("Downloads and queue are active")
            .setContentIntent(p).setOngoing(true).setOnlyAlertOnce(true).build();
    }
    private int notificationId(Job j){return 4000+(j.id.hashCode()&0x7fffffff)%20000;}
    private void schedule(Job j){
        if(controls.containsKey(j.id))return;
        Control c=new Control();controls.put(j.id,c);
        synchronized(lock){j.status="queued";j.phase="Queued";saveLocked();}
        ensureForeground();
        workers.execute(()->run(j,c));
    }
    private void command(String action,String id){
        Job j;
        synchronized(lock){j=jobs.get(id);}
        if(j==null)return;
        Control c=controls.get(id);
        if(action.equals(ACTION_PAUSE)){
            if(j.status.equals("queued") || j.status.equals("running")){
                if(c!=null){c.pause=true;HttpURLConnection con=c.connection;if(con!=null)con.disconnect();}
                synchronized(lock){j.status="paused";j.phase="Paused";j.speed=0;saveLocked();}
                TraceLog.add(this,"Pause requested for "+j.id.substring(0,8));
                notifyJob(j);
            }
        }else if(action.equals(ACTION_RESUME)||action.equals(ACTION_RETRY)){
            if(j.status.equals("paused") || j.status.equals("failed")){
                if(c!=null){c.resumeAfterStop=true;c.pause=true;HttpURLConnection con=c.connection;if(con!=null)con.disconnect();}
                else schedule(j);
                TraceLog.add(this,"Resume/retry requested for "+j.id.substring(0,8));
            }
        }else if(action.equals(ACTION_CANCEL)){
            if(!j.status.equals("completed")&&!j.status.equals("cancelled")){
                if(c!=null){c.cancel=true;HttpURLConnection con=c.connection;if(con!=null)con.disconnect();}
                synchronized(lock){j.status="cancelled";j.phase="Cancelled";j.speed=0;saveLocked();}
                if(c==null)deleteParts(j.id);
                TraceLog.add(this,"Cancelled job "+j.id.substring(0,8));
                notifications.cancel(notificationId(j));
            }
        }
    }
    private void run(Job j,Control c){
        File dir=partDir(j.id);
        File video=new File(dir,"video.part"),audio=new File(dir,"audio.part"),merged=new File(dir,"joined.mp4");
        try{
            check(c);
            if(!dir.isDirectory()&&!dir.mkdirs())throw new IOException("Cannot create persistent download directory");
            setStage(j,"running","Downloading video");
            fetch(j,c,j.url,video,false);
            check(c);
            File output=video;
            if(!j.audio.isEmpty()){
                setStage(j,"running","Downloading audio");
                fetch(j,c,j.audio,audio,true);
                check(c);
                setStage(j,"merging","Merging audio + video");
                long required=video.length()+audio.length()+SPACE_RESERVE;
                ensureSpace(dir,required);
                if(merged.exists()&&!merged.delete())throw new IOException("Cannot replace previous merged file");
                Mp4Joiner.merge(video,audio,merged);
                MediaProbe.verify(merged,true,true);
                output=merged;
                j.ext="mp4";
            }
            check(c);
            setStage(j,"verifying","Checking downloaded media");
            boolean wantsVideo=j.isVideo;
            MediaProbe.verify(output,wantsVideo,j.expectAudio);
            check(c);
            setStage(j,"saving","Saving to Downloads / MediaLab");
            Uri uri=publish(j,c,output,filename(j.title,j.id,j.ext),j.ext,wantsVideo);
            check(c);
            synchronized(lock){j.uri=uri.toString();j.status="completed";j.phase="Verified and saved";j.speed=0;saveLocked();}
            deleteParts(j.id);
            TraceLog.add(this,"Completed job "+j.id.substring(0,8)+" verified media and saved MediaStore entry");
            notifyComplete(j,true);
        }catch(Halt halted){
            synchronized(lock){
                if(c.cancel||j.status.equals("cancelled")){j.status="cancelled";j.phase="Cancelled";}
                else if(!c.resumeAfterStop){j.status="paused";j.phase="Paused — tap Resume";}
                j.speed=0;saveLocked();
            }
            if(c.cancel)deleteParts(j.id);
        }catch(Exception ex){
            synchronized(lock){
                if(c.cancel){j.status="cancelled";j.phase="Cancelled";}
                else if(c.pause){j.status="paused";j.phase="Paused — tap Resume";}
                else{j.status="failed";j.error=safeError(ex);j.phase="Failed: "+j.error;}
                j.speed=0;saveLocked();
            }
            if(c.cancel)deleteParts(j.id);
            else if(!c.pause){TraceLog.add(this,"Failed job "+j.id.substring(0,8)+" "+safeError(ex));notifyComplete(j,false);}
        }finally{
            controls.remove(j.id,c);
            notifications.cancel(notificationId(j));
            if(c.resumeAfterStop&&!c.cancel){
                synchronized(lock){j.status="queued";j.phase="Queued for resume";saveLocked();}
                schedule(j);
            }
            stopIfIdle();
        }
    }
        private void check(Control c)throws Halt{
        if(c.cancel)throw new Halt("Cancelled");
        if(c.pause)throw new Halt("Paused");
    }
    private void setStage(Job j,String status,String phase){
        synchronized(lock){j.status=status;j.phase=phase;j.speed=0;saveLocked();}
        TraceLog.add(this,"Job "+j.id.substring(0,8)+" phase="+phase);
        notifyJob(j);
    }
    private void fetch(Job j,Control c,String link,File file,boolean isAudio)throws IOException{
        if(!https(link))throw new IOException("Only HTTPS media URLs are supported");
        
        for(int attempt=1;attempt<=5;attempt++){
            check(c);
            try{
                downloadOnce(j,c,link,file,isAudio);
                return;
            }catch(Halt ex){throw ex;}
            catch(HttpFailure ex){
                if(ex.code==403||ex.code==401||ex.code==404){
                    throw new IOException("Media link unavailable (HTTP "+ex.code+"). Reopen the original page and select quality again.");
                }
                if(ex.code!=408&&ex.code!=429&&ex.code<500)throw ex;
                if(attempt==5)throw ex;
            }catch(IOException ex){
                if(attempt==5)throw ex;
            }
            check(c);
            synchronized(lock){j.attempts++;j.phase="Reconnecting (attempt "+(attempt+1)+"/5)";j.speed=0;saveLocked();}
            TraceLog.add(this,"Job "+j.id.substring(0,8)+" reconnect attempt "+(attempt+1));
            notifyJob(j);
            try{Thread.sleep(Math.min(8000,700L*(1<<attempt)));}
            catch(InterruptedException e){Thread.currentThread().interrupt();throw new Halt("Interrupted");}
        }
    }
    private void downloadOnce(Job j,Control c,String link,File file,boolean audio)throws IOException{
        long position=file.exists()?file.length():0;
        long expected=audio?j.audioTotal:j.videoTotal;
        if(expected>0&&position==expected)return;
        if(expected>0&&position>expected){if(!file.delete())throw new IOException("Cannot reset invalid fragment");position=0;}
        String etag=audio?j.audioEtag:j.videoEtag;
        String modified=audio?j.audioModified:j.videoModified;
        HttpURLConnection conn=null;
        try{
            conn=connect(link,position,etag,modified,c);
            int code=conn.getResponseCode();
            if(code==416){
                if(ResumePolicy.isComplete416(conn.getHeaderField("Content-Range"),position))return;
                if(file.exists()&&!file.delete())throw new IOException("Unable to reset invalid Range response");
                if(audio){j.audioTotal=-1;j.audioBytes=0;}else{j.videoTotal=-1;j.videoBytes=0;}
                throw new IOException("Range rejected; retrying from beginning");
            }
            if(code!=200&&code!=206)throw new HttpFailure(code);
            TraceLog.add(this,"Job "+j.id.substring(0,8)+" HTTP "+code+" offset="+position+" type="+(audio?"audio":"video"));
            long total=-1;boolean append=false;
            if(code==206){
                total=ResumePolicy.totalOf206(conn.getHeaderField("Content-Range"),position);
                append=position>0;
                String returnedEtag=value(conn.getHeaderField("ETag"));
                if(position>0&&!etag.isEmpty()&&!returnedEtag.isEmpty()&&!etag.equals(returnedEtag)){
                    if(file.exists()&&!file.delete())throw new IOException("Cannot reset changed media fragment");
                    if(audio){j.audioBytes=0;j.audioTotal=-1;j.audioEtag="";j.audioModified="";}
                    else{j.videoBytes=0;j.videoTotal=-1;j.videoEtag="";j.videoModified="";}
                    TraceLog.add(this,"Media ETag changed; restarting fragment from zero");
                    throw new IOException("Media changed since the partial download; restart safely");
                }
            }else{
                // Server ignored Range; restart with a fresh file, NEVER append duplicate bytes.
                if(position>0)TraceLog.add(this,"Range unsupported; safely restarting fragment from zero");
                position=0;
                long length=conn.getContentLengthLong();
                if(length>0)total=length;
            }
            String newEtag=value(conn.getHeaderField("ETag"));
            String newModified=value(conn.getHeaderField("Last-Modified"));
            if(total<=0 && code==206 && conn.getContentLengthLong()>0)total=position+conn.getContentLengthLong();
            if(audio){j.audioTotal=total;j.audioBytes=position;j.audioEtag=newEtag;j.audioModified=newModified;}
            else{j.videoTotal=total;j.videoBytes=position;j.videoEtag=newEtag;j.videoModified=newModified;}
            synchronized(lock){saveLocked();}
            long actual=position,lastUpdate=System.currentTimeMillis(),lastBytes=actual;
            try(InputStream input=conn.getInputStream();FileOutputStream output=new FileOutputStream(file,append)){
                byte[] buf=new byte[BUFFER];int n;
                while((n=input.read(buf))!=-1){
                    check(c);
                    if(file.getUsableSpace()<SPACE_RESERVE)throw new IOException("Insufficient storage for remaining media");
                    output.write(buf,0,n);actual+=n;
                    if(audio)j.audioBytes=actual;else j.videoBytes=actual;
                    long now=System.currentTimeMillis();
                    if(now-lastUpdate>=800){
                        j.speed=(actual-lastBytes)*1000.0/Math.max(1,now-lastUpdate);
                        synchronized(lock){saveLocked();}
                        notifyJob(j);lastUpdate=now;lastBytes=actual;
                    }
                }
                output.getFD().sync();
            }
            if(total>0&&actual!=total)throw new IOException("Incomplete media transfer ("+actual+" / "+total+" bytes)");
            if(actual<=0)throw new IOException("Media server returned an empty file");
            synchronized(lock){j.speed=0;saveLocked();}
            notifyJob(j);
        }finally{
            c.connection=null;
            if(conn!=null)conn.disconnect();
        }
    }
    private HttpURLConnection connect(String link,long pos,String etag,String modified,Control c)throws IOException{
        URL u=new URL(link);
        for(int redirect=0;redirect<=5;redirect++){
            if(!"https".equalsIgnoreCase(u.getProtocol()))throw new IOException("Insecure media redirect rejected");
            HttpURLConnection conn=(HttpURLConnection)u.openConnection();
            c.connection=conn;
            conn.setInstanceFollowRedirects(false);conn.setConnectTimeout(20000);conn.setReadTimeout(20000);
            conn.setRequestProperty("User-Agent","Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
            conn.setRequestProperty("Accept","*/*");conn.setRequestProperty("Accept-Encoding","identity");
            if(pos>0){
                conn.setRequestProperty("Range","bytes="+pos+"-");
                if(!etag.isEmpty())conn.setRequestProperty("If-Range",etag);
                else if(!modified.isEmpty())conn.setRequestProperty("If-Range",modified);
            }
            int code=conn.getResponseCode();
            if(code==301||code==302||code==303||code==307||code==308){
                String target=conn.getHeaderField("Location");
                conn.disconnect();c.connection=null;
                if(target==null)throw new IOException("Media redirect without Location");
                u=new URL(u,target);continue;
            }
            return conn;
        }
        throw new IOException("Too many redirects");
    }
    private static String value(String s){return s==null?"":s;}
    private void ensureSpace(File near,long required)throws IOException{
        if(near.getUsableSpace()<required)throw new IOException("Not enough free storage to merge and save video (need "+human(required)+")");
    }
    private Uri publish(Job j,Control c,File source,String name,String ext,boolean video)throws IOException{
        ensureSpace(source,source.length()+SPACE_RESERVE);
        String mime=ext.equals("mp4")?"video/mp4":ext.equals("m4a")?"audio/mp4":ext.equals("webm")?(video?"video/webm":"audio/webm"):ext.equals("mp3")?"audio/mpeg":"application/octet-stream";
        ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.DISPLAY_NAME,name);
        v.put(MediaStore.MediaColumns.MIME_TYPE,mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/MediaLab");
        v.put(MediaStore.MediaColumns.IS_PENDING,1);
        Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
        if(uri==null)throw new IOException("Unable to create Downloads entry");
        try{
            long count=0;
            try(InputStream in=new FileInputStream(source);OutputStream out=getContentResolver().openOutputStream(uri,"w")){
                if(out==null)throw new IOException("Unable to open Downloads entry");
                byte[] bytes=new byte[BUFFER];int n;
                while((n=in.read(bytes))!=-1){check(c);out.write(bytes,0,n);count+=n;}
                out.flush();
            }
            if(count!=source.length())throw new IOException("Saved file size mismatch");
            MediaProbe.verify(this,uri,video,j.expectAudio);
            ContentValues ready=new ContentValues();ready.put(MediaStore.MediaColumns.IS_PENDING,0);
            if(getContentResolver().update(uri,ready,null,null)<1)throw new IOException("Could not publish completed file");
            return uri;
        }catch(Exception ex){
            try{getContentResolver().delete(uri,null,null);}catch(Exception ignored){}
            if(ex instanceof IOException)throw (IOException)ex;
            throw new IOException("Cannot save completed file",ex);
        }
    }
    private void saveLocked(){
        JSONArray a=new JSONArray();
        for(Job j:jobs.values()){
            try{j.updated=System.currentTimeMillis();a.put(j.json());}catch(Exception ignored){}

        }
        // Private preferences intentionally retain media URLs for resume; never export this JSON.
        getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString("jobs",a.toString()).apply();
    }
    private void notifyJob(Job j){
        if(j.status.equals("completed")||j.status.equals("cancelled"))return;
        long total=j.total(),done=j.done();
        int pct=total>0?(int)Math.min(99,done*100/total):0;
        Intent open=new Intent(this,MainActivity.class).putExtra("open_downloads",true);
        PendingIntent p=PendingIntent.getActivity(this,notificationId(j),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=new Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(j.title).setContentText(j.phase+" • "+human(done)+" • "+human((long)j.speed)+"/s")
            .setContentIntent(p).setOnlyAlertOnce(true).setOngoing(true);
        b.setProgress(100,pct,total<0);
        notifications.notify(notificationId(j),b.build());
    }
    private void notifyComplete(Job j,boolean ok){
        Intent open=new Intent(this,MainActivity.class).putExtra("open_downloads",true);
        PendingIntent p=PendingIntent.getActivity(this,notificationId(j),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        notifications.notify(notificationId(j)+40000,new Notification.Builder(this,DONE_CHANNEL)
            .setSmallIcon(ok?android.R.drawable.stat_sys_download_done:android.R.drawable.stat_notify_error)
            .setContentTitle(ok?"MediaLab • Download complete":"MediaLab • Download failed")
            .setContentText(ok?j.title:j.error).setContentIntent(p).setAutoCancel(true).build());
    }
    private void stopIfIdle(){
        if(!controls.isEmpty())return;
        if(foreground){stopForeground(STOP_FOREGROUND_REMOVE);foreground=false;}
        stopSelfResult(newestStartId);
    }
    private File partDir(String id){return new File(new File(getFilesDir(),"medialab-partials"),id);}
    private void deleteParts(String id){
        File dir=partDir(id);File[] files=dir.listFiles();
        if(files!=null)for(File f:files)f.delete();
        dir.delete();
    }
    private static String filename(String title,String id,String ext){
        String safe=title.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_").trim();
        if(safe.length()>70)safe=safe.substring(0,70);
        if(safe.isEmpty())safe="MediaLab";
        return safe+"_"+id.substring(0,8)+"."+ext;
    }
    private static String safeError(Throwable ex){
        String s=ex.getMessage();if(s==null)s=ex.getClass().getSimpleName();
        s=s.replaceAll("https?://\\S+","[media URL]")
           .replaceAll("(?i)(token|cookie|signature|authorization)[=:]\\S+","[hidden]");
        return s.length()>180?s.substring(0,180):s;
    }
    static String human(long bytes){
        if(bytes<0)return "unknown";
        if(bytes<1024)return bytes+" B";
        double n=bytes/1024.0;String[] suffix={"KB","MB","GB","TB"};int i=0;
        while(n>=1024&&i<suffix.length-1){n/=1024;i++;}
        return String.format(Locale.US,"%.1f %s",n,suffix[i]);
    }
    @Override public void onDestroy(){
        for(Control c:controls.values()){
            c.pause=true;HttpURLConnection v=c.connection;if(v!=null)v.disconnect();
        }
        workers.shutdownNow();
        super.onDestroy();
    }
}
