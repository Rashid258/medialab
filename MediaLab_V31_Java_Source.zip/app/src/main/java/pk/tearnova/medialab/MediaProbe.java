package pk.tearnova.medialab;

import android.content.Context;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.io.File;
import java.io.IOException;

/** Validate local media containers; never declare completion on a corrupt or missing track. */
final class MediaProbe {
    static void verify(File f,boolean requireVideo,boolean requireAudio)throws IOException{
        if(!f.isFile()||f.length()==0)throw new IOException("Empty or missing media file");
        MediaExtractor e=new MediaExtractor();
        try{e.setDataSource(f.getAbsolutePath());inspect(e,requireVideo,requireAudio);}
        catch(RuntimeException ex){throw new IOException("Invalid media container",ex);}
        finally{e.release();}
    }
    static void verify(Context context,Uri uri,boolean requireVideo,boolean requireAudio)throws IOException{
        MediaExtractor e=new MediaExtractor();
        try{e.setDataSource(context,uri,null);inspect(e,requireVideo,requireAudio);}
        catch(RuntimeException ex){throw new IOException("Saved media is unreadable",ex);}
        finally{e.release();}
    }
    private static void inspect(MediaExtractor e,boolean wantVideo,boolean wantAudio)throws IOException{
        boolean video=false,audio=false;
        for(int i=0;i<e.getTrackCount();i++){
            MediaFormat f=e.getTrackFormat(i);String mime=f.getString(MediaFormat.KEY_MIME);
            if(mime==null)continue;
            if(mime.startsWith("video/"))video=true;
            if(mime.startsWith("audio/"))audio=true;
        }
        if(wantVideo&&!video)throw new IOException("Downloaded file has no playable video track");
        if(wantAudio&&!audio)throw new IOException("Downloaded file has no playable audio track");
    }
    private MediaProbe(){}
}
