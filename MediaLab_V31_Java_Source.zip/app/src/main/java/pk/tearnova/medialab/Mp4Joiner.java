package pk.tearnova.medialab;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMetadataRetriever;
import android.media.MediaMuxer;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;

/** Container-level merging: no transcoding, only compatible MP4-video and AAC-audio tracks. */
final class Mp4Joiner {
    static void merge(File video, File audio, File output) throws IOException {
        MediaExtractor vx = new MediaExtractor();
        MediaExtractor ax = new MediaExtractor();
        MediaMuxer mux = null;
        boolean started = false;
        try {
            vx.setDataSource(video.getAbsolutePath());
            ax.setDataSource(audio.getAbsolutePath());
            int vt = find(vx, "video/");
            int at = find(ax, "audio/");
            if (vt < 0 || at < 0) throw new IOException("MP4 video or audio track not found");
            MediaFormat vf = vx.getTrackFormat(vt);
            MediaFormat af = ax.getTrackFormat(at);
            String videoMime = vf.getString(MediaFormat.KEY_MIME);
            String audioMime = af.getString(MediaFormat.KEY_MIME);
            if (videoMime == null || audioMime == null ||
                !(videoMime.equals("video/avc") || videoMime.equals("video/hevc") || videoMime.equals("video/av01")) ||
                !audioMime.equals("audio/mp4a-latm")) {
                throw new IOException("Tracks cannot be muxed into MP4 without transcoding: " + videoMime + ", " + audioMime);
            }
            mux = new MediaMuxer(output.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int dstV = mux.addTrack(vf);
            int dstA = mux.addTrack(af);
            try {
                MediaMetadataRetriever meta = new MediaMetadataRetriever();
                meta.setDataSource(video.getAbsolutePath());
                String rotation = meta.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);
                if (rotation != null) mux.setOrientationHint(Integer.parseInt(rotation));
                meta.release();
            } catch (Exception ignored) { /* rotation metadata is optional */ }
            mux.start();
            started = true;
            transfer(vx, vt, mux, dstV);
            transfer(ax, at, mux, dstA);
        } catch (RuntimeException ex) {
            throw new IOException("Local MP4 merge failed", ex);
        } finally {
            if (mux != null) {
                if (started) try { mux.stop(); } catch (Exception ignored) { }
                mux.release();
            }
            vx.release();
            ax.release();
        }
    }
    private static int find(MediaExtractor e, String mimePrefix) {
        for (int i=0;i<e.getTrackCount();i++) {
            String mime=e.getTrackFormat(i).getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith(mimePrefix)) return i;
        }
        return -1;
    }
    private static void transfer(MediaExtractor src, int index, MediaMuxer dst, int dstIndex) throws IOException {
        src.selectTrack(index);
        ByteBuffer buffer = ByteBuffer.allocateDirect(2 * 1024 * 1024);
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (true) {
            long sampleLength = src.getSampleSize();
            if (sampleLength < 0) break;
            if (sampleLength > 32L * 1024 * 1024) throw new IOException("Oversized media sample");
            if (sampleLength > buffer.capacity()) {
                int capacity = (int)Math.min(32L * 1024 * 1024, sampleLength + 1024);
                buffer = ByteBuffer.allocateDirect(capacity);
            }
            buffer.clear();
            int bytes = src.readSampleData(buffer, 0);
            if (bytes < 0) break;
            if (bytes == buffer.capacity() && sampleLength > buffer.capacity()) throw new IOException("Truncated media sample");
            info.offset=0;
            info.size=bytes;
            info.presentationTimeUs=Math.max(0,src.getSampleTime());
            info.flags=src.getSampleFlags();
            dst.writeSampleData(dstIndex,buffer,info);
            if (!src.advance()) break;
        }
        src.unselectTrack(index);
    }
    private Mp4Joiner() { }
}
