package pk.tearnova.medialab;

import java.io.IOException;

/** No Android SDK needed to validate the Range boundary cases. */
public final class ResumePolicyTest {
    private static int passed=0;
    private static void eq(long a,long b){if(a!=b)throw new AssertionError(a+" != "+b);passed++;}
    private static void check(boolean b){if(!b)throw new AssertionError("Expected true");passed++;}
    private static void rejects(String v,long offset){
        try{ResumePolicy.totalOf206(v,offset);throw new AssertionError("Accepted invalid Range");}
        catch(IOException expected){passed++;}
    }
    public static void main(String[] args)throws Exception{
        eq(1000,ResumePolicy.totalOf206("bytes 500-999/1000",500));
        eq(-1,ResumePolicy.totalOf206("bytes 500-900/*",500));
        rejects("bytes 499-999/1000",500);
        rejects("bytes 500-1000/1000",500);
        rejects("bytes 500-100/1000",500);
        rejects("invalid",500);
        check(ResumePolicy.isComplete416("bytes */1000",1000));
        check(!ResumePolicy.isComplete416("bytes */1000",999));
        check(!ResumePolicy.isComplete416("bytes */0",0));
        System.out.println("PASS "+passed+" HTTP Range checks");
    }
}
