# MediaLab V3.1 — Java Android downloader repair

This is an **actual modification of MediaLab V3**, not a rewrite of the app or Snaptube code. Application ID remains `pk.tearnova.medialab.v3`; version code `4`, version name `0.3.1`. Minimum Android version: API 29 (Android 10).

## Changes made

- DownloadService now maintains multiple persistent jobs; its fixed pool permits **2 active transfers** and queues additional jobs, each with unique state, progress, and notification.
- Added true **Pause / Resume / Cancel / Retry**. Fragments are saved in `getFilesDir()/medialab-partials/<job-ID>/`, not cache. Interrupted jobs become paused and can be resumed after reopening the app.
- Resume uses `Range`, `If-Range` plus ETag/Last-Modified, validates HTTP 206 `Content-Range`, handles 416, and **restarts from byte zero when a server ignores Range with HTTP 200**. On partial or transient network failure, retries with bounded backoff and checks declared transfer length.
- A download is **not labeled complete** until it is merged if needed, media tracks are validated, data is written to `MediaStore.Downloads` in `Downloads/MediaLab`, the saved media is verified, and `IS_PENDING` is cleared.
- Diagnostic logs (without signed media URLs, headers or credentials) can be exported from the Downloads screen to a TXT file under `Downloads/MediaLab`.
- Improved Media3 preview: prioritize explicitly paired video+audio, attach audio focus, inspect selected audio tracks, notify when no selected audio exists. MP4 merge uses an adaptive-size sample buffer, with source and final track validation.
- Downloads screen renders all jobs with individual controls and status phases. User needs no broad storage permission on Android 10+ for the app's own MediaStore downloads.

## Important limitations

- Signed media URLs may **expire**. 401/403/404 means refresh the video page and select the quality again; this project does not bypass service authentication, anti-bot checks, DRM, or private content restrictions.
- MediaMuxer **does not transcode**. Some video/audio codecs cannot be merged and are reported as failures; MP3 transcoding is not included.
- Some providers do not support HTTP Range; resuming such content restarts it safely instead of corrupting the file.
- Download verification is best-effort structural media-track validation, **not a whole-file cryptographic checksum**. A provider may not publish one.
- Pause is supported during download/queue. Merging and MediaStore saving are intentionally kept atomic rather than being interrupted halfway.
- Device/runtime build has not been verified in this environment because Android SDK/Gradle are unavailable. The standalone HTTP Range policy regression tests pass (9 cases). Please run GitHub Actions and install/test on Android, then export diagnostics on errors.
- If replacing an older V3 debug APK signed by a different GitHub runner, Android may report a signature mismatch. Back up any important app data before uninstalling the old test build.

## Using GitHub Actions (Android phone only)

1. Upload **`MediaLab_V31_Java_Source.zip`** to the **root** of your `tearnova34-ctrl/medialab` GitHub repository. Do not extract it.
2. Create **`.github/workflows/medialab-v31-build.yml`** and paste the supplied small workflow (or upload the YAML into that exact path).
3. Actions > `MediaLab V3.1 - Java APK` > Run workflow > `main` > Run workflow.
4. After success, download the **`MediaLab-V31-Debug-APK`** artifact, extract it and install `app-debug.apk` using Android Files.
5. Test with a **public video you are authorized to download**, two simultaneous jobs, pause/reopen/resume, saved-file playback with sound. If an error occurs, Downloads > Export diagnostic TXT. Verify available space before a large download.

## Files

- `app/src/main/java/pk/tearnova/medialab/DownloadService.java`: persistent two-job download service and Range retries.
- `MainActivity.java`: independent job UI, player track diagnostics.
- `MediaProbe.java`: tracks verification on temp and saved media.
- `TraceLog.java`: redacted TXT diagnostic export.
- `ResumePolicy.java`: pure-Java HTTP Content-Range checks.
- `tests/.../ResumePolicyTest.java`: runnable on a JDK without Android SDK.
- `Mp4Joiner.java`: local MP4/AAC muxer.
- `LICENSE`: original GPL license kept intact.
